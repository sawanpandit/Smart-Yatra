import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { ThemeToggle } from "@/components/ThemeToggle";
import {
  Search,
  Menu,
  User,
  MapPin,
  Plane,
  MessageSquare,
  Users,
  Bell,
  Gift,
  HelpCircle,
  LogOut,
  LayoutDashboard,
  Share2,
  AlertTriangle,
} from "lucide-react";

const navLinks = [
  { label: "Destinations", href: "/search", icon: MapPin },
  { label: "Book", href: "/booking", icon: Plane },
  { label: "My Trips", href: "/trips", icon: Plane },
  { label: "Alerts", href: "/alerts", icon: AlertTriangle },
  { label: "AI Assistant", href: "/ai-chat", icon: MessageSquare },
  { label: "Friends", href: "/friends", icon: Users },
];

export function Header() {
  const [searchOpen, setSearchOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-white/[0.06] backdrop-blur-xl dark:bg-white/[0.06] dark:backdrop-blur-xl dark:shadow-[0_1px_0_0_rgba(255,255,255,0.06)]">
      <div className="container flex h-16 items-center justify-between gap-4">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 shrink-0">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
            <Plane className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="hidden font-heading text-xl font-bold text-foreground sm:block">
            Smart Yatra
          </span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Search */}
        <div className="hidden flex-1 max-w-md md:block">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search destinations..."
              className="pl-9 bg-muted/50 border-0 focus-visible:ring-primary"
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  navigate(`/search?q=${(e.target as HTMLInputElement).value}`);
                }
              }}
            />
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center gap-2">
          {/* Mobile search toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setSearchOpen(!searchOpen)}
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Notifications */}
          <Button variant="ghost" size="icon" asChild>
            <Link to="/notifications">
              <Bell className="h-5 w-5" />
            </Link>
          </Button>

          <ThemeToggle />

          {/* User dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <User className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem asChild>
                <Link to="/dashboard" className="flex items-center gap-2">
                  <LayoutDashboard className="h-4 w-4" /> Dashboard
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/profile" className="flex items-center gap-2">
                  <User className="h-4 w-4" /> Profile
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/rewards" className="flex items-center gap-2">
                  <Gift className="h-4 w-4" /> Rewards
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/referrals" className="flex items-center gap-2">
                  <Share2 className="h-4 w-4" /> Referrals
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/help" className="flex items-center gap-2">
                  <HelpCircle className="h-4 w-4" /> Help
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/auth/login" className="flex items-center gap-2">
                  <LogOut className="h-4 w-4" /> Login
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Mobile hamburger */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <div className="flex flex-col gap-1 pt-8">
                {navLinks.map((link) => (
                  <Link
                    key={link.href}
                    to={link.href}
                    className="flex items-center gap-3 rounded-md px-3 py-3 text-sm font-medium text-foreground transition-colors hover:bg-muted"
                  >
                    <link.icon className="h-5 w-5 text-primary" />
                    {link.label}
                  </Link>
                ))}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Mobile search bar */}
      {searchOpen && (
        <div className="border-t border-border p-3 md:hidden">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder="Search destinations..."
              className="pl-9"
              autoFocus
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  navigate(`/search?q=${(e.target as HTMLInputElement).value}`);
                  setSearchOpen(false);
                }
              }}
            />
          </div>
        </div>
      )}
    </header>
  );
}

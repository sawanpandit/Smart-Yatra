import { Header } from "./Header";
import { Footer } from "./Footer";

interface LayoutProps {
  children: React.ReactNode;
  hideNav?: boolean;
}

export function Layout({ children, hideNav }: LayoutProps) {
  return (
    <div className="flex min-h-screen flex-col">
      {!hideNav && <Header />}
      <main className="flex-1">{children}</main>
      {!hideNav && <Footer />}
    </div>
  );
}

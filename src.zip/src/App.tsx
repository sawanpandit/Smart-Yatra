import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Login from "./pages/auth/Login";
import Signup from "./pages/auth/Signup";
import VerifyEmail from "./pages/auth/VerifyEmail";
import Dashboard from "./pages/Dashboard";
import SearchPage from "./pages/SearchPage";
import DestinationDetails from "./pages/DestinationDetails";
import Trips from "./pages/Trips";
import TripDetails from "./pages/TripDetails";
import TripExpenses from "./pages/TripExpenses";
import Booking from "./pages/Booking";
import FlightBooking from "./pages/booking/FlightBooking";
import HotelBooking from "./pages/booking/HotelBooking";
import AiChat from "./pages/AiChat";
import ItineraryCreate from "./pages/ItineraryCreate";
import Friends from "./pages/Friends";
import Rewards from "./pages/Rewards";
import Referrals from "./pages/Referrals";
import Notifications from "./pages/Notifications";
import Profile from "./pages/Profile";
import Help from "./pages/Help";
import Alerts from "./pages/Alerts";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider defaultTheme="dark" enableSystem={false} attribute="class">
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/auth/login" element={<Login />} />
          <Route path="/auth/signup" element={<Signup />} />
          <Route path="/auth/verify-email" element={<VerifyEmail />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/search" element={<SearchPage />} />
          <Route path="/destination/:id" element={<DestinationDetails />} />
          <Route path="/trips" element={<Trips />} />
          <Route path="/trips/:id" element={<TripDetails />} />
          <Route path="/trips/:id/expenses" element={<TripExpenses />} />
          <Route path="/booking" element={<Booking />} />
          <Route path="/booking/flights" element={<FlightBooking />} />
          <Route path="/booking/hotels" element={<HotelBooking />} />
          <Route path="/ai-chat" element={<AiChat />} />
          <Route path="/itinerary/create" element={<ItineraryCreate />} />
          <Route path="/friends" element={<Friends />} />
          <Route path="/rewards" element={<Rewards />} />
          <Route path="/referrals" element={<Referrals />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/alerts" element={<Alerts />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/help" element={<Help />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;

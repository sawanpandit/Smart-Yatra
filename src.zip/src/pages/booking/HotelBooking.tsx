import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { motion } from "framer-motion";
import {
  Hotel, Search, Star, MapPin, Wifi, Car, Coffee,
  Dumbbell, SlidersHorizontal, Users, Check,
} from "lucide-react";

const hotels = [
  { id: 1, name: "The Mulia Resort & Villas", image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=250&fit=crop", rating: 4.9, reviews: 1240, price: 320, amenities: ["Pool", "Spa", "WiFi", "Gym"], location: "Nusa Dua, Bali" },
  { id: 2, name: "Alila Villas Uluwatu", image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=400&h=250&fit=crop", rating: 4.8, reviews: 890, price: 450, amenities: ["Pool", "Ocean View", "WiFi", "Restaurant"], location: "Uluwatu, Bali" },
  { id: 3, name: "Ubud Village Resort", image: "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=400&h=250&fit=crop", rating: 4.5, reviews: 650, price: 85, amenities: ["Pool", "WiFi", "Breakfast"], location: "Ubud, Bali" },
  { id: 4, name: "W Bali - Seminyak", image: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?w=400&h=250&fit=crop", rating: 4.7, reviews: 1100, price: 280, amenities: ["Pool", "Beach", "WiFi", "Spa", "Gym"], location: "Seminyak, Bali" },
  { id: 5, name: "Bamboo Eco Lodge", image: "https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?w=400&h=250&fit=crop", rating: 4.3, reviews: 320, price: 55, amenities: ["WiFi", "Breakfast", "Garden"], location: "Sidemen, Bali" },
];

const HotelBooking = () => {
  const [sortBy, setSortBy] = useState("rating");
  const [bookingHotel, setBookingHotel] = useState<number | null>(null);

  const sorted = [...hotels].sort((a, b) => {
    if (sortBy === "price-asc") return a.price - b.price;
    if (sortBy === "price-desc") return b.price - a.price;
    return b.rating - a.rating;
  });

  return (
    <Layout>
      <div className="container py-8">
        <h1 className="font-heading text-3xl font-bold mb-2">Find Hotels</h1>
        <p className="text-muted-foreground mb-6">Discover top-rated stays for your trip.</p>

        {/* Search */}
        <Card className="border-0 shadow-sm mb-8">
          <CardContent className="p-6">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
              <div className="space-y-2"><Label>Destination</Label><Input placeholder="Bali, Indonesia" /></div>
              <div className="space-y-2"><Label>Check-in</Label><Input type="date" defaultValue="2026-03-15" /></div>
              <div className="space-y-2"><Label>Check-out</Label><Input type="date" defaultValue="2026-03-22" /></div>
              <div className="space-y-2"><Label>Guests</Label>
                <Select defaultValue="2"><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4].map(n=><SelectItem key={n} value={String(n)}>{n} Guest{n>1?"s":""}</SelectItem>)}</SelectContent></Select>
              </div>
              <div className="space-y-2"><Label>Rooms</Label>
                <Select defaultValue="1"><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3].map(n=><SelectItem key={n} value={String(n)}>{n} Room{n>1?"s":""}</SelectItem>)}</SelectContent></Select>
              </div>
            </div>
            <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Hotels</Button>
          </CardContent>
        </Card>

        {/* Results header */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{hotels.length} hotels found</p>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-44"><SlidersHorizontal className="h-4 w-4 mr-2" /><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="rating">Top Rated</SelectItem>
              <SelectItem value="price-asc">Price: Low → High</SelectItem>
              <SelectItem value="price-desc">Price: High → Low</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Hotel cards */}
        <div className="space-y-4">
          {sorted.map((h, i) => (
            <motion.div key={h.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className="group overflow-hidden border-0 shadow-sm transition-all hover:shadow-md">
                <CardContent className="flex flex-col gap-4 p-0 sm:flex-row">
                  <div className="relative h-48 w-full overflow-hidden sm:h-auto sm:w-64 shrink-0">
                    <img src={h.image} alt={h.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                  </div>
                  <div className="flex flex-1 flex-col justify-between p-5">
                    <div>
                      <div className="flex items-start justify-between mb-1">
                        <h3 className="font-heading font-semibold text-lg">{h.name}</h3>
                        <div className="flex items-center gap-1 text-sm shrink-0">
                          <Star className="h-4 w-4 fill-secondary text-secondary" />
                          <span className="font-semibold">{h.rating}</span>
                          <span className="text-xs text-muted-foreground">({h.reviews})</span>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground flex items-center gap-1 mb-3">
                        <MapPin className="h-3 w-3" /> {h.location}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {h.amenities.map((a) => (
                          <Badge key={a} variant="secondary" className="text-xs rounded-full">{a}</Badge>
                        ))}
                      </div>
                    </div>
                    <div className="mt-4 flex items-end justify-between">
                      <div>
                        <span className="font-heading text-2xl font-bold text-primary">${h.price}</span>
                        <span className="text-sm text-muted-foreground">/night</span>
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button className="gap-2" onClick={() => setBookingHotel(h.id)}>
                            <Hotel className="h-4 w-4" /> Book Now
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader><DialogTitle>Book {h.name}</DialogTitle></DialogHeader>
                          <div className="space-y-4 pt-2">
                            <div className="rounded-lg bg-muted/50 p-3 flex items-center justify-between text-sm">
                              <span>7 nights × ${h.price}/night</span>
                              <span className="font-heading font-bold text-primary">${h.price * 7}</span>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                              <div className="space-y-2"><Label>First Name</Label><Input placeholder="John" /></div>
                              <div className="space-y-2"><Label>Last Name</Label><Input placeholder="Doe" /></div>
                            </div>
                            <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
                            <div className="space-y-2"><Label>Special Requests</Label><Input placeholder="Late check-in, extra pillows..." /></div>
                            <Button className="w-full gap-2"><Check className="h-4 w-4" /> Confirm Booking — ${h.price * 7}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default HotelBooking;

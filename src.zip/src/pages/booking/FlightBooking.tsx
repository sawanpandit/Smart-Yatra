import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { motion } from "framer-motion";
import {
  Plane, Search, ArrowRight, Clock, Filter, SlidersHorizontal,
  ArrowLeftRight, Calendar, Users, Luggage, ChevronDown,
} from "lucide-react";

const flights = [
  { id: 1, airline: "Singapore Airlines", code: "SQ-482", depart: "08:30", arrive: "13:45", duration: "5h 15m", stops: 0, price: 480, class: "Economy" },
  { id: 2, airline: "Garuda Indonesia", code: "GA-215", depart: "10:00", arrive: "16:30", duration: "6h 30m", stops: 1, price: 350, class: "Economy" },
  { id: 3, airline: "Emirates", code: "EK-358", depart: "23:55", arrive: "09:20", duration: "9h 25m", stops: 1, price: 520, class: "Economy" },
  { id: 4, airline: "Qatar Airways", code: "QR-946", depart: "14:15", arrive: "22:00", duration: "7h 45m", stops: 1, price: 410, class: "Economy" },
  { id: 5, airline: "Singapore Airlines", code: "SQ-942", depart: "19:00", arrive: "23:30", duration: "4h 30m", stops: 0, price: 620, class: "Business" },
];

const FlightBooking = () => {
  const [sortBy, setSortBy] = useState("price");
  const [selectedFlight, setSelectedFlight] = useState<number | null>(null);

  const sorted = [...flights].sort((a, b) => {
    if (sortBy === "price") return a.price - b.price;
    if (sortBy === "duration") return a.duration.localeCompare(b.duration);
    return 0;
  });

  return (
    <Layout>
      <div className="container py-8">
        <h1 className="font-heading text-3xl font-bold mb-2">Search Flights</h1>
        <p className="text-muted-foreground mb-6">Find the best fares for your next adventure.</p>

        {/* Search form */}
        <Card className="border-0 shadow-sm mb-8">
          <CardContent className="p-6">
            <Tabs defaultValue="roundtrip">
              <TabsList className="mb-4">
                <TabsTrigger value="roundtrip">Round Trip</TabsTrigger>
                <TabsTrigger value="oneway">One Way</TabsTrigger>
              </TabsList>
              <TabsContent value="roundtrip">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                  <div className="space-y-2">
                    <Label>From</Label>
                    <Input placeholder="Singapore (SIN)" />
                  </div>
                  <div className="relative space-y-2">
                    <Label>To</Label>
                    <Input placeholder="Bali (DPS)" />
                    <button className="absolute left-1/2 top-1/2 -translate-x-1/2 translate-y-0.5 rounded-full bg-muted p-1.5 hidden lg:block">
                      <ArrowLeftRight className="h-3 w-3" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <Label>Departure</Label>
                    <Input type="date" defaultValue="2026-03-15" />
                  </div>
                  <div className="space-y-2">
                    <Label>Return</Label>
                    <Input type="date" defaultValue="2026-03-22" />
                  </div>
                  <div className="space-y-2">
                    <Label>Passengers</Label>
                    <Select defaultValue="1">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5].map((n) => <SelectItem key={n} value={String(n)}>{n} Passenger{n > 1 ? "s" : ""}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Flights</Button>
              </TabsContent>
              <TabsContent value="oneway">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="space-y-2"><Label>From</Label><Input placeholder="Singapore (SIN)" /></div>
                  <div className="space-y-2"><Label>To</Label><Input placeholder="Bali (DPS)" /></div>
                  <div className="space-y-2"><Label>Departure</Label><Input type="date" defaultValue="2026-03-15" /></div>
                  <div className="space-y-2"><Label>Passengers</Label>
                    <Select defaultValue="1"><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4,5].map(n=><SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select>
                  </div>
                </div>
                <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Flights</Button>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Results */}
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-muted-foreground">{flights.length} flights found</p>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40"><SlidersHorizontal className="h-4 w-4 mr-2" /><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="price">Price: Low → High</SelectItem>
              <SelectItem value="duration">Duration</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          {sorted.map((f, i) => (
            <motion.div key={f.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
              <Card className={`border-0 shadow-sm transition-all cursor-pointer hover:shadow-md ${selectedFlight === f.id ? "ring-2 ring-primary" : ""}`} onClick={() => setSelectedFlight(f.id)}>
                <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Plane className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-heading font-semibold text-sm">{f.airline}</p>
                      <p className="text-xs text-muted-foreground">{f.code} · {f.class}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 text-sm">
                    <div className="text-center">
                      <p className="font-heading font-bold">{f.depart}</p>
                      <p className="text-xs text-muted-foreground">SIN</p>
                    </div>
                    <div className="flex flex-col items-center">
                      <p className="text-xs text-muted-foreground">{f.duration}</p>
                      <div className="flex items-center gap-1">
                        <div className="h-px w-16 bg-border" />
                        <Plane className="h-3 w-3 text-muted-foreground" />
                      </div>
                      <p className="text-xs text-muted-foreground">{f.stops === 0 ? "Direct" : `${f.stops} stop`}</p>
                    </div>
                    <div className="text-center">
                      <p className="font-heading font-bold">{f.arrive}</p>
                      <p className="text-xs text-muted-foreground">DPS</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-heading text-xl font-bold text-primary">${f.price}</p>
                    <p className="text-xs text-muted-foreground">per person</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {selectedFlight && (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-6">
            <Card className="border-0 shadow-lg">
              <CardContent className="p-6">
                <h3 className="font-heading font-semibold text-lg mb-4">Complete Your Booking</h3>
                <div className="grid gap-4 sm:grid-cols-2">
                  <div className="space-y-2"><Label>Full Name</Label><Input placeholder="As on passport" /></div>
                  <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
                  <div className="space-y-2"><Label>Passport Number</Label><Input placeholder="A12345678" /></div>
                  <div className="space-y-2"><Label>Date of Birth</Label><Input type="date" /></div>
                </div>
                <Button className="mt-6 gap-2" size="lg">
                  <Plane className="h-4 w-4" /> Confirm Booking — ${flights.find(f => f.id === selectedFlight)?.price}
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </Layout>
  );
};

export default FlightBooking;

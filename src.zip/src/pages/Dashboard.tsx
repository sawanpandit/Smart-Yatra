import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Calendar,
  DollarSign,
  MapPin,
  Plane,
  TrendingUp,
  CloudSun,
  Sparkles,
  ArrowRight,
  Clock,
  Users,
  Star,
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";

const upcomingTrips = [
  { id: "1", destination: "Bali, Indonesia", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=300&h=200&fit=crop", startDate: "Mar 15", endDate: "Mar 22", status: "planned" as const, participants: 3 },
  { id: "2", destination: "Tokyo, Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=300&h=200&fit=crop", startDate: "Apr 5", endDate: "Apr 12", status: "planned" as const, participants: 2 },
  { id: "3", destination: "Paris, France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=300&h=200&fit=crop", startDate: "May 20", endDate: "May 28", status: "planned" as const, participants: 4 },
];

const recentActivity = [
  { id: 1, action: "Booked flight to Bali", time: "2 hours ago", icon: Plane },
  { id: 2, action: "Added expense: Hotel deposit $250", time: "5 hours ago", icon: DollarSign },
  { id: 3, action: "Invited Sarah to Tokyo trip", time: "1 day ago", icon: Users },
  { id: 4, action: "AI generated itinerary for Paris", time: "2 days ago", icon: Sparkles },
];

const weatherAlerts = [
  { destination: "Bali", temp: "29°C", condition: "Sunny", alert: false },
  { destination: "Tokyo", temp: "18°C", condition: "Cloudy", alert: false },
  { destination: "Paris", temp: "12°C", condition: "Rain expected", alert: true },
];

const expenseData = [
  { name: "Flights", amount: 1200 },
  { name: "Hotels", amount: 950 },
  { name: "Food", amount: 400 },
  { name: "Activities", amount: 300 },
  { name: "Transport", amount: 200 },
];

const pieData = [
  { name: "Spent", value: 3050 },
  { name: "Remaining", value: 1950 },
];

const PIE_COLORS = ["hsl(224, 76%, 40%)", "hsl(214, 32%, 91%)"];

const aiSuggestions = [
  "🏖️ Perfect beach weather in Maldives this week",
  "🗾 Cherry blossom season starting in Kyoto",
  "💰 Flash sale: 30% off Dubai hotels",
];

const fadeUp = {
  hidden: { opacity: 0, y: 15 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.08, duration: 0.4 } }),
};

const statusColor = {
  planned: "bg-primary/10 text-primary",
  active: "bg-accent/10 text-accent",
  completed: "bg-muted text-muted-foreground",
};

const Dashboard = () => {
  return (
    <Layout>
      <div className="container py-8">
        {/* Welcome */}
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-heading text-3xl font-bold">Welcome back, Traveler! 👋</h1>
            <p className="text-muted-foreground">Here's what's happening with your trips.</p>
          </div>
          <Button className="gap-2 self-start" asChild>
            <Link to="/itinerary/create">
              <Plus className="h-4 w-4" /> New Trip
            </Link>
          </Button>
        </div>

        {/* Quick Actions */}
        <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {[
            { label: "New Trip", icon: Plus, href: "/itinerary/create", color: "bg-primary/10 text-primary" },
            { label: "Book Travel", icon: Plane, href: "/booking", color: "bg-primary/10 text-primary" },
            { label: "My Bookings", icon: Calendar, href: "/trips", color: "bg-secondary/10 text-secondary-foreground" },
            { label: "Expenses", icon: DollarSign, href: "/trips", color: "bg-accent/10 text-accent" },
            { label: "Explore", icon: MapPin, href: "/search", color: "bg-primary/10 text-primary" },
          ].map((action, i) => (
            <motion.div key={action.label} custom={i} initial="hidden" animate="visible" variants={fadeUp}>
              <Link to={action.href}>
                <Card className="group cursor-pointer border-0 shadow-sm transition-all hover:shadow-md hover:-translate-y-0.5">
                  <CardContent className="flex flex-col items-center gap-2 p-4 text-center">
                    <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${action.color} transition-transform group-hover:scale-110`}>
                      <action.icon className="h-5 w-5" />
                    </div>
                    <span className="text-sm font-medium">{action.label}</span>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main content - 2 cols */}
          <div className="space-y-6 lg:col-span-2">
            {/* Upcoming Trips */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="flex-row items-center justify-between space-y-0 pb-4">
                <CardTitle className="font-heading text-lg">Upcoming Trips</CardTitle>
                <Button variant="ghost" size="sm" className="gap-1 text-primary" asChild>
                  <Link to="/trips">View all <ArrowRight className="h-3 w-3" /></Link>
                </Button>
              </CardHeader>
              <CardContent className="space-y-3">
                {upcomingTrips.map((trip, i) => (
                  <motion.div key={trip.id} custom={i} initial="hidden" animate="visible" variants={fadeUp}>
                    <Link to={`/trips/${trip.id}`}>
                      <div className="group flex gap-4 rounded-xl p-3 transition-colors hover:bg-muted/50">
                        <img src={trip.image} alt={trip.destination} className="h-16 w-24 rounded-lg object-cover" loading="lazy" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="font-heading font-semibold text-sm truncate">{trip.destination}</h3>
                            <Badge variant="secondary" className={`text-xs ${statusColor[trip.status]}`}>
                              {trip.status}
                            </Badge>
                          </div>
                          <div className="mt-1 flex items-center gap-3 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{trip.startDate} - {trip.endDate}</span>
                            <span className="flex items-center gap-1"><Users className="h-3 w-3" />{trip.participants}</span>
                          </div>
                        </div>
                        <ArrowRight className="h-4 w-4 self-center text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </CardContent>
            </Card>

            {/* Expense Summary */}
            <div className="grid gap-6 sm:grid-cols-2">
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="font-heading text-lg flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-primary" /> Spending by Category
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={expenseData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                      <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip
                        contentStyle={{ borderRadius: "0.75rem", border: "none", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}
                        formatter={(value: number) => [`$${value}`, "Amount"]}
                      />
                      <Bar dataKey="amount" fill="hsl(224, 76%, 40%)" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="font-heading text-lg flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-accent" /> Budget Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center">
                  <ResponsiveContainer width="100%" height={160}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={70} dataKey="value" strokeWidth={0}>
                        {pieData.map((_, idx) => (
                          <Cell key={idx} fill={PIE_COLORS[idx]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value: number) => `$${value}`} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex gap-4 text-xs">
                    <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-primary" /> Spent: $3,050</span>
                    <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-border" /> Left: $1,950</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Sidebar - 1 col */}
          <div className="space-y-6">
            {/* AI Suggestions */}
            <Card className="border-0 shadow-sm bg-gradient-to-br from-primary/5 to-accent/5">
              <CardHeader className="pb-3">
                <CardTitle className="font-heading text-lg flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" /> AI Suggestions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {aiSuggestions.map((s, i) => (
                  <div key={i} className="rounded-lg bg-card p-3 text-sm shadow-sm cursor-pointer transition-colors hover:bg-muted/50">
                    {s}
                  </div>
                ))}
                <Button variant="ghost" size="sm" className="w-full mt-1 text-primary" asChild>
                  <Link to="/ai-chat">Ask AI for more <ArrowRight className="h-3 w-3 ml-1" /></Link>
                </Button>
              </CardContent>
            </Card>

            {/* Weather Alerts */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="font-heading text-lg flex items-center gap-2">
                  <CloudSun className="h-4 w-4 text-secondary" /> Weather Updates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {weatherAlerts.map((w) => (
                  <div key={w.destination} className="flex items-center justify-between text-sm">
                    <div>
                      <p className="font-medium">{w.destination}</p>
                      <p className="text-xs text-muted-foreground">{w.condition}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-heading font-semibold">{w.temp}</p>
                      {w.alert && <Badge variant="destructive" className="text-xs">Alert</Badge>}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="font-heading text-lg flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" /> Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {recentActivity.map((a) => (
                  <div key={a.id} className="flex items-start gap-3 text-sm">
                    <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-muted">
                      <a.icon className="h-3.5 w-3.5 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium leading-tight">{a.action}</p>
                      <p className="text-xs text-muted-foreground">{a.time}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Dashboard;

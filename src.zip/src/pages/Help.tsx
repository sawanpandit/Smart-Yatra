import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  HelpCircle, Search, MessageSquare, Mail, BookOpen, Video, Send,
} from "lucide-react";

const faqs = [
  { q: "How do I create a new trip?", a: "Go to your Dashboard and click 'New Trip', or navigate to the Itinerary Creator from the main menu. Follow the step-by-step wizard to set your destination, dates, and activities." },
  { q: "How does the AI assistant work?", a: "Our AI travel assistant uses advanced language models to provide personalized recommendations based on your preferences, budget, and travel history. You can chat with it anytime from the AI Assistant page." },
  { q: "How do I invite friends to a trip?", a: "Open your trip details and click 'Invite' in the participants section. Enter your friend's email address, and they'll receive an invitation to join your trip planning." },
  { q: "How does expense splitting work?", a: "In the trip expenses section, add expenses and select who paid. The system automatically calculates how much each person owes. You can view the split summary in the sidebar." },
  { q: "How do I earn rewards points?", a: "You earn points through bookings (flights, hotels), completing trip reviews, and referring friends. Visit the Rewards page to see all earning opportunities and redeem your points." },
  { q: "Can I cancel a booking?", a: "Yes, go to your trip details, find the booking in the Bookings tab, and click the cancellation option. Cancellation policies vary by provider." },
];

const Help = () => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredFaqs = faqs.filter(
    (f) => f.q.toLowerCase().includes(searchQuery.toLowerCase()) || f.a.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <HelpCircle className="mx-auto h-12 w-12 text-primary mb-3" />
          <h1 className="font-heading text-3xl font-bold mb-2">Help & Support</h1>
          <p className="text-muted-foreground">Find answers to common questions or get in touch.</p>
        </div>

        {/* Search */}
        <div className="relative mb-8 max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search for help..." className="h-12 pl-10 text-base" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} />
        </div>

        {/* Quick links */}
        <div className="mb-8 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { icon: BookOpen, label: "Guides", desc: "Getting started" },
            { icon: Video, label: "Tutorials", desc: "Video walkthroughs" },
            { icon: MessageSquare, label: "Live Chat", desc: "Chat with us" },
            { icon: Mail, label: "Email", desc: "support@smartyatra.com" },
          ].map((item) => (
            <Card key={item.label} className="border-0 shadow-sm cursor-pointer hover:shadow-md transition-shadow text-center">
              <CardContent className="p-4">
                <item.icon className="mx-auto h-6 w-6 text-primary mb-2" />
                <p className="font-heading font-semibold text-sm">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ */}
        <Card className="border-0 shadow-sm mb-8">
          <CardHeader><CardTitle className="font-heading text-lg">Frequently Asked Questions</CardTitle></CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              {filteredFaqs.map((f, i) => (
                <AccordionItem key={i} value={`faq-${i}`}>
                  <AccordionTrigger className="text-sm font-medium text-left">{f.q}</AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
            {filteredFaqs.length === 0 && (
              <p className="py-6 text-center text-sm text-muted-foreground">No matching questions found.</p>
            )}
          </CardContent>
        </Card>

        {/* Contact form */}
        <Card className="border-0 shadow-sm">
          <CardHeader><CardTitle className="font-heading text-lg">Contact Support</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Name</Label><Input placeholder="Your name" /></div>
              <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
            </div>
            <div className="space-y-2"><Label>Subject</Label><Input placeholder="How can we help?" /></div>
            <div className="space-y-2"><Label>Message</Label><textarea className="flex min-h-[120px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2" placeholder="Describe your issue..." /></div>
            <Button className="gap-2"><Send className="h-4 w-4" /> Send Message</Button>
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Help;

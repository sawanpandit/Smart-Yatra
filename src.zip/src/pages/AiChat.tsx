import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Sparkles, Plane, Hotel, MapPin, Trash2, Bot, User } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

const quickSuggestions = [
  "Best destinations for March?",
  "Plan a 5-day trip to Bali under $1500",
  "What should I pack for Japan in spring?",
  "Recommend budget-friendly hotels in Paris",
];

const AiChat = () => {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! I'm your Smart Yatra AI assistant. 🌍 I can help you discover destinations, plan itineraries, suggest activities, and answer any travel questions. What would you like to explore?" },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (text: string) => {
    if (!text.trim()) return;
    const userMsg: Msg = { role: "user", content: text };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    // Placeholder AI response — will be replaced with real AI in Phase 6
    setTimeout(() => {
      const responses = [
        "Great question! Based on current weather patterns and seasonal trends, I'd recommend exploring Southeast Asia in March. Countries like Thailand, Vietnam, and Indonesia offer warm weather, fewer crowds, and excellent value. Would you like me to create a detailed itinerary for any of these destinations?",
        "I'd love to help you plan that! Let me consider your budget, travel dates, and preferences. For a well-rounded experience, I suggest splitting your budget: 40% accommodation, 25% activities, 20% food, and 15% transport. Shall I generate a day-by-day itinerary?",
        "That's a fantastic choice! Here are some key tips: pack layers for variable weather, bring comfortable walking shoes, and don't forget a portable charger. I can also recommend must-visit spots and hidden gems if you'd like!",
      ];
      const reply: Msg = { role: "assistant", content: responses[Math.floor(Math.random() * responses.length)] };
      setMessages((prev) => [...prev, reply]);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <Layout>
      <div className="container flex h-[calc(100vh-8rem)] flex-col py-4">
        {/* Header */}
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
              <Sparkles className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="font-heading text-lg font-bold">AI Travel Assistant</h1>
              <p className="text-xs text-muted-foreground">Powered by Smart Yatra AI</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="gap-1 text-muted-foreground" onClick={() => setMessages([messages[0]])}>
            <Trash2 className="h-3 w-3" /> Clear
          </Button>
        </div>

        {/* Messages */}
        <Card className="flex-1 border-0 shadow-sm overflow-hidden">
          <ScrollArea className="h-full p-4">
            <div className="space-y-4">
              <AnimatePresence>
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ duration: 0.2 }}
                    className={`flex gap-3 ${msg.role === "user" ? "justify-end" : ""}`}
                  >
                    {msg.role === "assistant" && (
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent">
                        <Bot className="h-4 w-4 text-primary-foreground" />
                      </div>
                    )}
                    <div className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-muted rounded-bl-sm"
                    }`}>
                      {msg.content}
                    </div>
                    {msg.role === "user" && (
                      <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-muted">
                        <User className="h-4 w-4" />
                      </div>
                    )}
                  </motion.div>
                ))}
              </AnimatePresence>

              {isLoading && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex gap-3">
                  <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-accent">
                    <Bot className="h-4 w-4 text-primary-foreground" />
                  </div>
                  <div className="rounded-2xl rounded-bl-sm bg-muted px-4 py-3">
                    <div className="flex gap-1">
                      <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/50" style={{ animationDelay: "0ms" }} />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/50" style={{ animationDelay: "150ms" }} />
                      <span className="h-2 w-2 animate-bounce rounded-full bg-muted-foreground/50" style={{ animationDelay: "300ms" }} />
                    </div>
                  </div>
                </motion.div>
              )}
              <div ref={scrollRef} />
            </div>
          </ScrollArea>
        </Card>

        {/* Quick suggestions */}
        {messages.length <= 2 && (
          <div className="mt-3 flex flex-wrap gap-2">
            {quickSuggestions.map((s) => (
              <Button key={s} variant="outline" size="sm" className="rounded-full text-xs" onClick={() => sendMessage(s)}>
                {s}
              </Button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="mt-3 flex gap-2">
          <Input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me anything about travel..."
            className="h-12 text-base"
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage(input)}
            disabled={isLoading}
          />
          <Button size="lg" className="h-12 px-6 gap-2" onClick={() => sendMessage(input)} disabled={!input.trim() || isLoading}>
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </Layout>
  );
};

export default AiChat;

import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import { Gift, Star, Trophy, Zap, ArrowRight, Clock, Check } from "lucide-react";

const rewards = [
  { id: 1, name: "$25 Flight Voucher", points: 500, image: "✈️" },
  { id: 2, name: "Hotel Upgrade", points: 750, image: "🏨" },
  { id: 3, name: "Spa Experience", points: 1000, image: "🧖" },
  { id: 4, name: "Premium AI Assistant", points: 300, image: "🤖" },
];

const history = [
  { date: "Feb 20", description: "Redeemed: $25 Flight Voucher", points: -500 },
  { date: "Feb 15", description: "Booking: Bali flight", points: +200 },
  { date: "Feb 10", description: "Referral bonus", points: +100 },
  { date: "Jan 28", description: "Booking: Tokyo hotel", points: +150 },
];

const earningOps = [
  { action: "Book a flight", points: "+200 pts", icon: Zap },
  { action: "Book a hotel", points: "+150 pts", icon: Star },
  { action: "Refer a friend", points: "+100 pts", icon: Gift },
  { action: "Complete trip review", points: "+50 pts", icon: Check },
];

const Rewards = () => {
  const totalPoints = 1250;
  const tierProgress = 62;

  return (
    <Layout>
      <div className="container py-8">
        <h1 className="font-heading text-3xl font-bold mb-6">Rewards Program</h1>

        {/* Points summary */}
        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          <Card className="border-0 shadow-sm bg-gradient-to-br from-primary to-accent text-primary-foreground">
            <CardContent className="p-6 text-center">
              <Trophy className="mx-auto h-8 w-8 mb-2 opacity-80" />
              <p className="text-3xl font-heading font-bold">{totalPoints.toLocaleString()}</p>
              <p className="text-sm opacity-80">Available Points</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground mb-2">Current Tier</p>
              <p className="font-heading text-xl font-bold flex items-center gap-2"><Star className="h-5 w-5 fill-secondary text-secondary" /> Silver Explorer</p>
              <div className="mt-3">
                <div className="flex justify-between text-xs mb-1"><span>Progress to Gold</span><span>{tierProgress}%</span></div>
                <Progress value={tierProgress} className="h-2" />
              </div>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-6">
              <p className="text-sm text-muted-foreground mb-2">Lifetime Earned</p>
              <p className="font-heading text-xl font-bold">3,450 pts</p>
              <p className="text-xs text-muted-foreground mt-1">Across 8 bookings</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="catalog">
          <TabsList>
            <TabsTrigger value="catalog">Rewards Catalog</TabsTrigger>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="earn">How to Earn</TabsTrigger>
          </TabsList>

          <TabsContent value="catalog" className="mt-4">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {rewards.map((r, i) => (
                <motion.div key={r.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card className="border-0 shadow-sm text-center hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="text-4xl mb-3">{r.image}</div>
                      <h3 className="font-heading font-semibold text-sm mb-1">{r.name}</h3>
                      <p className="text-xs text-muted-foreground mb-3">{r.points} points</p>
                      <Button size="sm" variant={totalPoints >= r.points ? "default" : "outline"} disabled={totalPoints < r.points} className="w-full">
                        {totalPoints >= r.points ? "Redeem" : "Not enough pts"}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="history" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                {history.map((h, i) => (
                  <div key={i} className={`flex items-center justify-between py-3 ${i < history.length - 1 ? "border-b border-border" : ""}`}>
                    <div>
                      <p className="font-medium text-sm">{h.description}</p>
                      <p className="text-xs text-muted-foreground">{h.date}</p>
                    </div>
                    <span className={`font-heading font-bold text-sm ${h.points > 0 ? "text-accent" : "text-destructive"}`}>
                      {h.points > 0 ? "+" : ""}{h.points}
                    </span>
                  </div>
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="earn" className="mt-4">
            <div className="grid gap-3 sm:grid-cols-2">
              {earningOps.map((e) => (
                <Card key={e.action} className="border-0 shadow-sm">
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                        <e.icon className="h-5 w-5 text-primary" />
                      </div>
                      <span className="font-medium text-sm">{e.action}</span>
                    </div>
                    <Badge variant="secondary" className="font-heading">{e.points}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Rewards;

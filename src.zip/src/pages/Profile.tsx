import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  User, Camera, Bell, Shield, Globe, MapPin, Palette,
  Save, Link as LinkIcon,
} from "lucide-react";

const Profile = () => {
  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        <h1 className="font-heading text-3xl font-bold mb-6">Profile Settings</h1>

        {/* Avatar & name */}
        <Card className="border-0 shadow-sm mb-6">
          <CardContent className="flex items-center gap-6 p-6">
            <div className="relative">
              <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/10 font-heading text-3xl font-bold text-primary">T</div>
              <button className="absolute bottom-0 right-0 flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground shadow">
                <Camera className="h-3.5 w-3.5" />
              </button>
            </div>
            <div>
              <h2 className="font-heading text-xl font-bold">Traveler</h2>
              <p className="text-sm text-muted-foreground">traveler@example.com</p>
              <Badge variant="secondary" className="mt-1 text-xs">Silver Explorer</Badge>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="personal">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="personal">Personal</TabsTrigger>
            <TabsTrigger value="preferences">Travel Preferences</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          <TabsContent value="personal" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>First Name</Label><Input defaultValue="Smart" /></div>
                  <div className="space-y-2"><Label>Last Name</Label><Input defaultValue="Traveler" /></div>
                </div>
                <div className="space-y-2"><Label>Email</Label><Input type="email" defaultValue="traveler@example.com" /></div>
                <div className="space-y-2"><Label>Phone</Label><Input type="tel" defaultValue="+1 234 567 890" /></div>
                <div className="space-y-2"><Label>Bio</Label><Input placeholder="Tell us about yourself..." /></div>
                <Button className="gap-2"><Save className="h-4 w-4" /> Save Changes</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="preferences" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label>Preferred Destinations</Label>
                  <Select defaultValue="beach"><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beach">Beach & Islands</SelectItem>
                      <SelectItem value="city">City Breaks</SelectItem>
                      <SelectItem value="adventure">Adventure & Outdoors</SelectItem>
                      <SelectItem value="cultural">Cultural & Historical</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Budget Range</Label>
                  <Select defaultValue="mid"><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="budget">Budget ($0-$1000)</SelectItem>
                      <SelectItem value="mid">Mid-Range ($1000-$3000)</SelectItem>
                      <SelectItem value="luxury">Luxury ($3000+)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Preferred Currency</Label>
                  <Select defaultValue="usd"><SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="usd">USD ($)</SelectItem>
                      <SelectItem value="eur">EUR (€)</SelectItem>
                      <SelectItem value="gbp">GBP (£)</SelectItem>
                      <SelectItem value="jpy">JPY (¥)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button className="gap-2"><Save className="h-4 w-4" /> Save Preferences</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="notifications" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-5">
                {[
                  { label: "Booking confirmations", desc: "Get notified when bookings are confirmed", default: true },
                  { label: "Weather alerts", desc: "Receive alerts for saved destinations", default: true },
                  { label: "Price drops", desc: "Notified when flight/hotel prices drop", default: true },
                  { label: "Friend activity", desc: "Updates from your travel friends", default: false },
                  { label: "AI recommendations", desc: "Personalized travel suggestions", default: true },
                  { label: "Marketing emails", desc: "Deals, offers, and newsletter", default: false },
                ].map((n) => (
                  <div key={n.label} className="flex items-center justify-between">
                    <div>
                      <p className="font-medium text-sm">{n.label}</p>
                      <p className="text-xs text-muted-foreground">{n.desc}</p>
                    </div>
                    <Switch defaultChecked={n.default} />
                  </div>
                ))}
                <Button className="gap-2"><Save className="h-4 w-4" /> Save</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="security" className="mt-4">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2"><Label>Current Password</Label><Input type="password" /></div>
                <div className="space-y-2"><Label>New Password</Label><Input type="password" /></div>
                <div className="space-y-2"><Label>Confirm New Password</Label><Input type="password" /></div>
                <Button className="gap-2"><Shield className="h-4 w-4" /> Update Password</Button>
                <div className="border-t border-border pt-4 mt-4">
                  <h3 className="font-heading font-semibold text-sm mb-3">Linked Accounts</h3>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2"><LinkIcon className="h-4 w-4" /> Google</span>
                      <Button variant="outline" size="sm">Connect</Button>
                    </div>
                    <div className="flex items-center justify-between text-sm">
                      <span className="flex items-center gap-2"><LinkIcon className="h-4 w-4" /> Facebook</span>
                      <Button variant="outline" size="sm">Connect</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Profile;

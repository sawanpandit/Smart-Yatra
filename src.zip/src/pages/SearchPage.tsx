import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import {
  Search as SearchIcon,
  MapPin,
  Star,
  Filter,
  SlidersHorizontal,
  X,
  Sparkles,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const allDestinations = [
  { id: "1", name: "Bali, Indonesia", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=500&h=350&fit=crop", rating: 4.8, price: 899, category: "Beach", season: "Summer" },
  { id: "2", name: "Paris, France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=500&h=350&fit=crop", rating: 4.9, price: 1200, category: "City", season: "Spring" },
  { id: "3", name: "Tokyo, Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=500&h=350&fit=crop", rating: 4.7, price: 1050, category: "City", season: "Spring" },
  { id: "4", name: "Santorini, Greece", image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=500&h=350&fit=crop", rating: 4.9, price: 1100, category: "Beach", season: "Summer" },
  { id: "5", name: "Machu Picchu, Peru", image: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=500&h=350&fit=crop", rating: 4.8, price: 950, category: "Adventure", season: "Winter" },
  { id: "6", name: "Dubai, UAE", image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=500&h=350&fit=crop", rating: 4.6, price: 1300, category: "City", season: "Winter" },
  { id: "7", name: "Maldives", image: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=500&h=350&fit=crop", rating: 4.9, price: 1800, category: "Beach", season: "Winter" },
  { id: "8", name: "Swiss Alps", image: "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=500&h=350&fit=crop", rating: 4.7, price: 1400, category: "Adventure", season: "Winter" },
  { id: "9", name: "New York, USA", image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=500&h=350&fit=crop", rating: 4.5, price: 1100, category: "City", season: "Fall" },
];

const aiTags = ["🏖️ Beach Getaway", "🏔️ Adventure", "🏙️ City Break", "💰 Budget-Friendly", "🌸 Spring Picks"];

const SearchPage = () => {
  const [searchParams] = useSearchParams();
  const initialQuery = searchParams.get("q") || "";
  const [query, setQuery] = useState(initialQuery);
  const [sortBy, setSortBy] = useState("rating");
  const [priceRange, setPriceRange] = useState([0, 2000]);
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [page, setPage] = useState(1);
  const perPage = 6;

  const filtered = allDestinations
    .filter((d) => {
      const matchesQuery = !query || d.name.toLowerCase().includes(query.toLowerCase());
      const matchesPrice = d.price >= priceRange[0] && d.price <= priceRange[1];
      const matchesCategory = categoryFilter === "all" || d.category === categoryFilter;
      return matchesQuery && matchesPrice && matchesCategory;
    })
    .sort((a, b) => {
      if (sortBy === "price-asc") return a.price - b.price;
      if (sortBy === "price-desc") return b.price - a.price;
      return b.rating - a.rating;
    });

  const totalPages = Math.ceil(filtered.length / perPage);
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  const FilterPanel = () => (
    <div className="space-y-6">
      <div>
        <Label className="mb-2 block font-heading font-semibold text-sm">Price Range</Label>
        <Slider min={0} max={2000} step={50} value={priceRange} onValueChange={setPriceRange} />
        <div className="mt-1 flex justify-between text-xs text-muted-foreground">
          <span>${priceRange[0]}</span>
          <span>${priceRange[1]}</span>
        </div>
      </div>
      <div>
        <Label className="mb-2 block font-heading font-semibold text-sm">Category</Label>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            <SelectItem value="Beach">Beach</SelectItem>
            <SelectItem value="City">City</SelectItem>
            <SelectItem value="Adventure">Adventure</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="mb-2 block font-heading font-semibold text-sm">Season</Label>
        <Select defaultValue="all">
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Seasons</SelectItem>
            <SelectItem value="Spring">Spring</SelectItem>
            <SelectItem value="Summer">Summer</SelectItem>
            <SelectItem value="Fall">Fall</SelectItem>
            <SelectItem value="Winter">Winter</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Button variant="outline" size="sm" className="w-full" onClick={() => { setPriceRange([0, 2000]); setCategoryFilter("all"); }}>
        <X className="h-3 w-3 mr-1" /> Clear Filters
      </Button>
    </div>
  );

  return (
    <Layout>
      <div className="container py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="font-heading text-3xl font-bold mb-2">Explore Destinations</h1>
          <p className="text-muted-foreground">Discover your next adventure with AI-powered recommendations.</p>
        </div>

        {/* Search bar */}
        <div className="mb-6 flex gap-3">
          <div className="relative flex-1">
            <SearchIcon className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => { setQuery(e.target.value); setPage(1); }}
              placeholder="Search destinations, countries, activities..."
              className="h-12 pl-10 text-base"
            />
          </div>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="h-12 w-44 hidden sm:flex">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="rating">Top Rated</SelectItem>
              <SelectItem value="price-asc">Price: Low → High</SelectItem>
              <SelectItem value="price-desc">Price: High → Low</SelectItem>
            </SelectContent>
          </Select>
          {/* Mobile filter */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="h-12 w-12 lg:hidden">
                <Filter className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader><SheetTitle>Filters</SheetTitle></SheetHeader>
              <div className="mt-6"><FilterPanel /></div>
            </SheetContent>
          </Sheet>
        </div>

        {/* AI Tags */}
        <div className="mb-6 flex flex-wrap gap-2">
          <Sparkles className="h-4 w-4 text-primary mt-1" />
          {aiTags.map((tag) => (
            <Badge key={tag} variant="secondary" className="cursor-pointer rounded-full px-3 py-1 hover:bg-primary/10 transition-colors">
              {tag}
            </Badge>
          ))}
        </div>

        <div className="flex gap-8">
          {/* Desktop filters sidebar */}
          <aside className="hidden w-56 shrink-0 lg:block">
            <Card className="border-0 shadow-sm sticky top-24">
              <CardContent className="p-5">
                <h3 className="font-heading font-semibold mb-4 flex items-center gap-2">
                  <Filter className="h-4 w-4" /> Filters
                </h3>
                <FilterPanel />
              </CardContent>
            </Card>
          </aside>

          {/* Results grid */}
          <div className="flex-1">
            <p className="mb-4 text-sm text-muted-foreground">{filtered.length} destinations found</p>
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {paginated.map((dest, i) => (
                <motion.div
                  key={dest.id}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.05, duration: 0.3 }}
                >
                  <Link to={`/destination/${dest.id}`}>
                    <Card className="group overflow-hidden border-0 shadow-sm transition-all hover:shadow-lg hover:-translate-y-1 cursor-pointer">
                      <div className="relative h-44 overflow-hidden">
                        <img src={dest.image} alt={dest.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />
                        <Badge className="absolute top-3 left-3 bg-card/90 text-foreground backdrop-blur-sm text-xs">{dest.category}</Badge>
                        <div className="absolute bottom-3 right-3 flex items-center gap-1 rounded-full bg-card/90 px-2 py-0.5 text-xs font-semibold backdrop-blur-sm">
                          <Star className="h-3 w-3 fill-secondary text-secondary" /> {dest.rating}
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2 mb-1">
                          <MapPin className="h-4 w-4 text-primary" />
                          <h3 className="font-heading font-semibold truncate">{dest.name}</h3>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">Best in {dest.season}</span>
                          <span className="font-heading font-bold text-primary">From ${dest.price}</span>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="mt-8 flex items-center justify-center gap-2">
                <Button variant="outline" size="icon" disabled={page === 1} onClick={() => setPage(page - 1)}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                {Array.from({ length: totalPages }, (_, i) => (
                  <Button key={i + 1} variant={page === i + 1 ? "default" : "outline"} size="icon" onClick={() => setPage(i + 1)}>
                    {i + 1}
                  </Button>
                ))}
                <Button variant="outline" size="icon" disabled={page === totalPages} onClick={() => setPage(page + 1)}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default SearchPage;

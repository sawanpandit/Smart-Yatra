import { useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Plus, MapPin, Calendar, Users, Search, MoreHorizontal,
  Copy, Share2, Trash2, ArrowRight,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const trips = [
  { id: "1", destination: "Bali, Indonesia", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=400&h=250&fit=crop", startDate: "Mar 15, 2026", endDate: "Mar 22, 2026", status: "planned" as const, participants: 3, budget: 2700 },
  { id: "2", destination: "Tokyo, Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&h=250&fit=crop", startDate: "Apr 5, 2026", endDate: "Apr 12, 2026", status: "planned" as const, participants: 2, budget: 3200 },
  { id: "3", destination: "Paris, France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400&h=250&fit=crop", startDate: "Jan 10, 2026", endDate: "Jan 18, 2026", status: "completed" as const, participants: 4, budget: 4500 },
  { id: "4", destination: "Santorini, Greece", image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=400&h=250&fit=crop", startDate: "Dec 1, 2025", endDate: "Dec 8, 2025", status: "completed" as const, participants: 2, budget: 3100 },
];

const statusStyles = {
  planned: "bg-primary/10 text-primary",
  active: "bg-accent/10 text-accent",
  completed: "bg-muted text-muted-foreground",
};

const Trips = () => {
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const filtered = trips.filter((t) => {
    const matchesQuery = !query || t.destination.toLowerCase().includes(query.toLowerCase());
    const matchesStatus = statusFilter === "all" || t.status === statusFilter;
    return matchesQuery && matchesStatus;
  });

  return (
    <Layout>
      <div className="container py-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-heading text-3xl font-bold">My Trips</h1>
            <p className="text-muted-foreground">{trips.length} trips total</p>
          </div>
          <Button className="gap-2 self-start" asChild>
            <Link to="/itinerary/create"><Plus className="h-4 w-4" /> Create Trip</Link>
          </Button>
        </div>

        {/* Filters */}
        <div className="mb-6 flex gap-3">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search trips..." className="pl-9" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="planned">Planned</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Trip cards */}
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((trip, i) => (
            <motion.div
              key={trip.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05, duration: 0.3 }}
            >
              <Card className="group overflow-hidden border-0 shadow-sm transition-all hover:shadow-lg cursor-pointer">
                <Link to={`/trips/${trip.id}`}>
                  <div className="relative h-40 overflow-hidden">
                    <img src={trip.image} alt={trip.destination} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                    <Badge className={`absolute top-3 left-3 ${statusStyles[trip.status]} text-xs capitalize`}>{trip.status}</Badge>
                  </div>
                </Link>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <Link to={`/trips/${trip.id}`}>
                      <h3 className="font-heading font-semibold flex items-center gap-1.5 hover:text-primary transition-colors">
                        <MapPin className="h-4 w-4 text-primary" /> {trip.destination}
                      </h3>
                    </Link>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="h-4 w-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem><Share2 className="h-4 w-4 mr-2" /> Share</DropdownMenuItem>
                        <DropdownMenuItem><Copy className="h-4 w-4 mr-2" /> Duplicate</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive"><Trash2 className="h-4 w-4 mr-2" /> Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Calendar className="h-3 w-3" />{trip.startDate} - {trip.endDate}</span>
                  </div>
                  <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1"><Users className="h-3 w-3" /> {trip.participants} travelers</span>
                    <span className="font-heading font-semibold text-primary text-sm">${trip.budget.toLocaleString()}</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="mt-12 text-center">
            <MapPin className="mx-auto h-12 w-12 text-muted-foreground/50 mb-3" />
            <p className="text-muted-foreground">No trips found. Start planning your next adventure!</p>
            <Button className="mt-4 gap-2" asChild>
              <Link to="/itinerary/create"><Plus className="h-4 w-4" /> Create Trip</Link>
            </Button>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Trips;

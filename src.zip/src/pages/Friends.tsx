import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from "framer-motion";
import {
  Users, UserPlus, Search, Check, X, MapPin, Clock,
  MessageSquare, Mail,
} from "lucide-react";

const friends = [
  { id: 1, name: "Sarah Chen", avatar: "S", status: "online", sharedTrips: 3 },
  { id: 2, name: "James Kim", avatar: "J", status: "offline", sharedTrips: 1 },
  { id: 3, name: "Marco Rossi", avatar: "M", status: "online", sharedTrips: 2 },
  { id: 4, name: "Priya Sharma", avatar: "P", status: "offline", sharedTrips: 0 },
];

const pending = [
  { id: 5, name: "Alex Johnson", avatar: "A", email: "alex@example.com" },
  { id: 6, name: "Lisa Wang", avatar: "L", email: "lisa@example.com" },
];

const activityFeed = [
  { user: "Sarah Chen", action: "booked a trip to Tokyo", time: "2h ago" },
  { user: "Marco Rossi", action: "shared photos from Paris trip", time: "5h ago" },
  { user: "James Kim", action: "created a new itinerary for Dubai", time: "1d ago" },
];

const Friends = () => {
  const [query, setQuery] = useState("");

  const filteredFriends = friends.filter((f) => f.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <Layout>
      <div className="container py-8">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="font-heading text-3xl font-bold">Travel Friends</h1>
            <p className="text-muted-foreground">{friends.length} friends</p>
          </div>
          <Button className="gap-2"><UserPlus className="h-4 w-4" /> Add Friend</Button>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Tabs defaultValue="friends">
              <TabsList>
                <TabsTrigger value="friends">Friends</TabsTrigger>
                <TabsTrigger value="pending">Pending ({pending.length})</TabsTrigger>
              </TabsList>

              <TabsContent value="friends" className="mt-4 space-y-3">
                <div className="relative mb-3">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input placeholder="Search friends..." className="pl-9" value={query} onChange={(e) => setQuery(e.target.value)} />
                </div>
                {filteredFriends.map((f, i) => (
                  <motion.div key={f.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                    <Card className="border-0 shadow-sm">
                      <CardContent className="flex items-center justify-between p-4">
                        <div className="flex items-center gap-3">
                          <div className="relative">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 font-heading font-semibold text-primary">{f.avatar}</div>
                            <span className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-card ${f.status === "online" ? "bg-accent" : "bg-muted-foreground/30"}`} />
                          </div>
                          <div>
                            <p className="font-semibold text-sm">{f.name}</p>
                            <p className="text-xs text-muted-foreground">{f.sharedTrips} shared trips</p>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="icon" className="h-8 w-8"><MessageSquare className="h-4 w-4" /></Button>
                          <Button variant="outline" size="sm">View Profile</Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </TabsContent>

              <TabsContent value="pending" className="mt-4 space-y-3">
                {pending.map((p) => (
                  <Card key={p.id} className="border-0 shadow-sm">
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary/20 font-heading font-semibold text-secondary-foreground">{p.avatar}</div>
                        <div>
                          <p className="font-semibold text-sm">{p.name}</p>
                          <p className="text-xs text-muted-foreground">{p.email}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" className="gap-1"><Check className="h-3 w-3" /> Accept</Button>
                        <Button size="sm" variant="ghost" className="text-destructive"><X className="h-3 w-3" /></Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Activity feed */}
          <Card className="border-0 shadow-sm h-fit">
            <CardHeader className="pb-3">
              <CardTitle className="font-heading text-base flex items-center gap-2"><Clock className="h-4 w-4" /> Friend Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {activityFeed.map((a, i) => (
                <div key={i} className="text-sm">
                  <p><span className="font-semibold">{a.user}</span> {a.action}</p>
                  <p className="text-xs text-muted-foreground">{a.time}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Friends;

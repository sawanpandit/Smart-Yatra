import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Layout } from "@/components/layout/Layout";
import {
  Search,
  MapPin,
  Plane,
  Hotel,
  Star,
  Calendar,
  Sparkles,
  ArrowRight,
  Globe,
  Shield,
  Zap,
  Users,
  TrendingUp,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

const featuredDestinations = [
  { name: "Bali, Indonesia", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600&h=400&fit=crop", rating: 4.8, price: "$899" },
  { name: "Paris, France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&h=400&fit=crop", rating: 4.9, price: "$1,200" },
  { name: "Tokyo, Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&h=400&fit=crop", rating: 4.7, price: "$1,050" },
  { name: "Santorini, Greece", image: "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=600&h=400&fit=crop", rating: 4.9, price: "$1,100" },
  { name: "Machu Picchu, Peru", image: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?w=600&h=400&fit=crop", rating: 4.8, price: "$950" },
  { name: "Dubai, UAE", image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&h=400&fit=crop", rating: 4.6, price: "$1,300" },
];

const aiSuggestions = [
  { tag: "🏖️ Beach Escape", desc: "Perfect weather in Maldives right now" },
  { tag: "🏔️ Mountain Trek", desc: "Best season for Nepal hiking" },
  { tag: "🎭 Cultural Trip", desc: "Festival season in Kyoto, Japan" },
  { tag: "💰 Budget-Friendly", desc: "Vietnam under $50/day" },
];

const testimonials = [
  { name: "Sarah Chen", role: "Travel Blogger", text: "Smart Yatra's AI planned my entire 2-week Southeast Asia trip. It saved me hours of research!", rating: 5 },
  { name: "Marco Rossi", role: "Digital Nomad", text: "The expense tracking and budget distribution feature is a game-changer for group trips.", rating: 5 },
  { name: "Priya Sharma", role: "Adventure Traveler", text: "Real-time weather alerts helped us reroute our trek and avoid a storm. Literally a lifesaver!", rating: 5 },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.1, duration: 0.5 },
  }),
};

const Index = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [carouselIndex, setCarouselIndex] = useState(0);
  const visibleCount = 3;

  const nextSlide = () => setCarouselIndex((i) => Math.min(i + 1, featuredDestinations.length - visibleCount));
  const prevSlide = () => setCarouselIndex((i) => Math.max(i - 1, 0));

  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary/90 to-accent py-20 lg:py-32">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -top-40 -right-40 h-96 w-96 rounded-full bg-secondary blur-3xl" />
          <div className="absolute -bottom-40 -left-40 h-96 w-96 rounded-full bg-accent blur-3xl" />
        </div>
        <div className="container relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="mx-auto max-w-3xl text-center"
          >
            <h1 className="mb-6 font-heading text-4xl font-extrabold tracking-tight text-primary-foreground sm:text-5xl lg:text-6xl">
              Travel Smarter with{" "}
              <span className="text-secondary">AI-Powered</span> Planning
            </h1>
            <p className="mb-10 text-lg text-primary-foreground/80">
              Discover destinations, plan itineraries, and book everything — all powered by intelligent recommendations tailored to you.
            </p>
            <div className="mx-auto flex max-w-xl gap-2 rounded-xl bg-card/95 p-2 shadow-xl backdrop-blur-sm">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Where do you want to go?"
                  className="h-12 border-0 pl-10 text-base focus-visible:ring-0"
                  onKeyDown={(e) => e.key === "Enter" && navigate(`/search?q=${searchQuery}`)}
                />
              </div>
              <Button
                size="lg"
                className="h-12 gap-2 bg-secondary text-secondary-foreground hover:bg-secondary/90"
                onClick={() => navigate(`/search?q=${searchQuery}`)}
              >
                <Search className="h-4 w-4" /> Explore
              </Button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Quick Booking Widgets */}
      <section className="container -mt-8 relative z-20">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { icon: Plane, label: "Flights", desc: "Find best fares", href: "/booking/flights" },
            { icon: Hotel, label: "Hotels", desc: "Top-rated stays", href: "/booking/hotels" },
            { icon: Calendar, label: "Activities", desc: "Local experiences", href: "/search" },
          ].map((item, i) => (
            <motion.div key={item.label} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <Card className="group cursor-pointer border-0 shadow-lg transition-all hover:shadow-xl hover:-translate-y-1" onClick={() => navigate(item.href)}>
                <CardContent className="flex items-center gap-4 p-5">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                    <item.icon className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold">{item.label}</h3>
                    <p className="text-sm text-muted-foreground">{item.desc}</p>
                  </div>
                  <ArrowRight className="ml-auto h-5 w-5 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Featured Destinations Carousel */}
      <section className="container py-20">
        <div className="mb-8 flex items-end justify-between">
          <div>
            <p className="mb-1 text-sm font-semibold uppercase tracking-wider text-primary">Explore</p>
            <h2 className="font-heading text-3xl font-bold">Featured Destinations</h2>
          </div>
          <div className="hidden gap-2 sm:flex">
            <Button variant="outline" size="icon" onClick={prevSlide} disabled={carouselIndex === 0}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={nextSlide} disabled={carouselIndex >= featuredDestinations.length - visibleCount}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="overflow-hidden">
          <motion.div
            className="flex gap-6"
            animate={{ x: `-${carouselIndex * (100 / visibleCount)}%` }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
          >
            {featuredDestinations.map((dest) => (
              <div key={dest.name} className="min-w-[calc(33.333%-1rem)] max-sm:min-w-[calc(100%-1rem)] max-lg:min-w-[calc(50%-1rem)]">
                <Card className="group overflow-hidden border-0 shadow-md transition-all hover:shadow-xl cursor-pointer">
                  <div className="relative h-52 overflow-hidden">
                    <img src={dest.image} alt={dest.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" loading="lazy" />
                    <div className="absolute bottom-3 left-3 flex items-center gap-1 rounded-full bg-card/90 px-3 py-1 text-xs font-semibold backdrop-blur-sm">
                      <Star className="h-3 w-3 fill-secondary text-secondary" /> {dest.rating}
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-primary" />
                        <h3 className="font-heading font-semibold">{dest.name}</h3>
                      </div>
                      <span className="font-heading font-bold text-primary">{dest.price}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* AI Suggestions */}
      <section className="bg-muted/50 py-20">
        <div className="container">
          <div className="mb-8 text-center">
            <div className="mb-2 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-1.5 text-sm font-semibold text-primary">
              <Sparkles className="h-4 w-4" /> Powered by AI
            </div>
            <h2 className="font-heading text-3xl font-bold">Smart Recommendations</h2>
            <p className="mx-auto mt-2 max-w-lg text-muted-foreground">
              Our AI analyzes seasons, weather, and your preferences to suggest the perfect trip.
            </p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {aiSuggestions.map((s, i) => (
              <motion.div key={s.tag} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
                <Card className="cursor-pointer border-0 shadow-sm transition-all hover:shadow-lg hover:-translate-y-1">
                  <CardContent className="p-5">
                    <p className="mb-2 text-lg font-semibold">{s.tag}</p>
                    <p className="text-sm text-muted-foreground">{s.desc}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Smart Yatra */}
      <section className="container py-20">
        <div className="mb-12 text-center">
          <h2 className="font-heading text-3xl font-bold">Why Smart Yatra?</h2>
        </div>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { icon: Sparkles, title: "AI-Powered", desc: "Intelligent recommendations tailored to your style and budget." },
            { icon: Shield, title: "Real-Time Alerts", desc: "Weather and safety notifications so you're always prepared." },
            { icon: Users, title: "Group Planning", desc: "Invite friends, split expenses, and plan collaboratively." },
            { icon: TrendingUp, title: "Earn Rewards", desc: "Points on every booking, redeemable for exclusive perks." },
          ].map((feature, i) => (
            <motion.div key={feature.title} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp} className="text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                <feature.icon className="h-7 w-7" />
              </div>
              <h3 className="mb-2 font-heading font-semibold">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Testimonials */}
      <section className="bg-muted/50 py-20">
        <div className="container">
          <div className="mb-10 text-center">
            <h2 className="font-heading text-3xl font-bold">What Travelers Say</h2>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            {testimonials.map((t, i) => (
              <motion.div key={t.name} custom={i} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
                <Card className="h-full border-0 shadow-sm">
                  <CardContent className="flex h-full flex-col p-6">
                    <div className="mb-3 flex gap-0.5">
                      {Array.from({ length: t.rating }).map((_, j) => (
                        <Star key={j} className="h-4 w-4 fill-secondary text-secondary" />
                      ))}
                    </div>
                    <p className="mb-4 flex-1 text-sm text-muted-foreground italic">"{t.text}"</p>
                    <div>
                      <p className="font-heading font-semibold text-sm">{t.name}</p>
                      <p className="text-xs text-muted-foreground">{t.role}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-primary to-accent py-20">
        <div className="container text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5 }}>
            <Globe className="mx-auto mb-4 h-12 w-12 text-primary-foreground/80" />
            <h2 className="mb-4 font-heading text-3xl font-bold text-primary-foreground">
              Start Your Journey Today
            </h2>
            <p className="mx-auto mb-8 max-w-md text-primary-foreground/80">
              Join thousands of smart travelers who plan better trips with AI.
            </p>
            <div className="flex justify-center gap-4">
              <Button size="lg" variant="secondary" className="gap-2" asChild>
                <Link to="/auth/signup">
                  Get Started Free <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" className="border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/10" asChild>
                <Link to="/search">Explore Destinations</Link>
              </Button>
            </div>
          </motion.div>
        </div>
      </section>
    </Layout>
  );
};

export default Index;

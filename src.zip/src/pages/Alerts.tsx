import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertTriangle,
  CloudRain,
  Flame,
  Leaf,
  Shield,
  Sparkles,
  MapPin,
  Clock,
  RefreshCw,
} from "lucide-react";

type AlertType = "safety" | "weather" | "disaster" | "environment";
type Severity = "critical" | "warning" | "info";

const alertTypeMeta: Record<AlertType, { label: string; icon: typeof CloudRain; color: string }> = {
  safety: { label: "Safety", icon: Shield, color: "text-amber-500" },
  weather: { label: "Weather", icon: CloudRain, color: "text-sky-500" },
  disaster: { label: "Disaster", icon: Flame, color: "text-red-500" },
  environment: { label: "Environment", icon: Leaf, color: "text-emerald-500" },
};

const severityStyles: Record<Severity, string> = {
  critical: "bg-red-500/20 text-red-400 border-red-500/30",
  warning: "bg-amber-500/20 text-amber-400 border-amber-500/30",
  info: "bg-blue-500/20 text-blue-400 border-blue-500/30",
};

const mockAlerts = [
  {
    id: "1",
    type: "weather" as AlertType,
    severity: "warning" as Severity,
    title: "Heavy rain expected in Bali",
    region: "Bali, Indonesia",
    summary: "AI analysis: 80% chance of heavy rainfall Mar 15–17. Possible flooding in low-lying areas.",
    recommendation: "Postpone beach and outdoor activities. Keep travel documents dry.",
    timestamp: "2 min ago",
    source: "AI + local weather",
  },
  {
    id: "2",
    type: "safety" as AlertType,
    severity: "info" as Severity,
    title: "Increased tourist advisories in Paris",
    region: "Paris, France",
    summary: "Higher than usual tourist congestion and pickpocket reports in central arrondissements.",
    recommendation: "Secure valuables, use anti-theft bags, avoid crowded metros at peak hours.",
    timestamp: "15 min ago",
    source: "AI + travel advisories",
  },
  {
    id: "3",
    type: "disaster" as AlertType,
    severity: "critical" as Severity,
    title: "Earthquake aftershock advisory — Japan",
    region: "Tokyo & Kanto region",
    summary: "Seismic monitoring indicates continued aftershock risk. No tsunami threat at this time.",
    recommendation: "Know evacuation routes. Keep emergency kit ready. Follow local authority updates.",
    timestamp: "1 hr ago",
    source: "AI + JMA",
  },
  {
    id: "4",
    type: "environment" as AlertType,
    severity: "warning" as Severity,
    title: "Air quality decline — Delhi NCR",
    region: "Delhi, Noida, Gurgaon",
    summary: "AQI rising to unhealthy levels. Sensitive groups should limit prolonged outdoor exposure.",
    recommendation: "Wear N95 if outdoors. Reschedule strenuous outdoor activities. Use air purifiers indoors.",
    timestamp: "45 min ago",
    source: "AI + CPCB",
  },
  {
    id: "5",
    type: "weather" as AlertType,
    severity: "info" as Severity,
    title: "Pollen count high — Kyoto",
    region: "Kyoto, Japan",
    summary: "Cherry blossom season driving elevated pollen. Mild allergy alert for sensitive travelers.",
    recommendation: "Carry antihistamines. Consider masks in parks during peak bloom.",
    timestamp: "3 hr ago",
    source: "AI + local sensors",
  },
  {
    id: "6",
    type: "safety" as AlertType,
    severity: "warning" as Severity,
    title: "Road closures on mountain routes",
    region: "Swiss Alps",
    summary: "Snow and avalanche control causing temporary closures on several high-altitude passes.",
    recommendation: "Check road status before driving. Prefer rail for intercity travel this week.",
    timestamp: "1 hr ago",
    source: "AI + traffic authority",
  },
];

const Alerts = () => {
  const [lastUpdated, setLastUpdated] = useState<Date>(() => new Date());
  const [filter, setFilter] = useState<AlertType | "all">("all");

  useEffect(() => {
    const t = setInterval(() => setLastUpdated(new Date()), 60_000);
    return () => clearInterval(t);
  }, []);

  const filtered = filter === "all" ? mockAlerts : mockAlerts.filter((a) => a.type === filter);

  return (
    <Layout>
      <div className="container py-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="mb-1 flex items-center gap-2">
              <h1 className="font-heading text-3xl font-bold">AI Alerts</h1>
              <Badge variant="secondary" className="gap-1 text-xs">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
                Live
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Real-time safety, weather, disaster & environment alerts powered by AI.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <RefreshCw className="h-3.5 w-3.5" />
              Updated {lastUpdated.toLocaleTimeString()}
            </span>
            <Button variant="outline" size="sm" asChild>
              <Link to="/ai-chat" className="gap-2">
                <Sparkles className="h-4 w-4" /> Ask AI
              </Link>
            </Button>
          </div>
        </div>

        <Tabs value={filter} onValueChange={(v) => setFilter(v as AlertType | "all")} className="space-y-6">
          <TabsList className="flex flex-wrap gap-1 bg-white/[0.06] p-1 h-auto">
            <TabsTrigger value="all" className="gap-1.5 data-[state=active]:bg-white/10">
              <AlertTriangle className="h-4 w-4" /> All
            </TabsTrigger>
            {(Object.entries(alertTypeMeta) as [AlertType, (typeof alertTypeMeta)[AlertType]][]).map(([key, meta]) => (
              <TabsTrigger key={key} value={key} className={`gap-1.5 ${meta.color} data-[state=active]:bg-white/10`}>
                <meta.icon className="h-4 w-4" /> {meta.label}
              </TabsTrigger>
            ))}
          </TabsList>

          <div className="mt-0 space-y-4">
            {filtered.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center text-muted-foreground">
                  No alerts in this category right now.
                </CardContent>
              </Card>
            ) : (
              filtered.map((alert, i) => {
                const meta = alertTypeMeta[alert.type];
                const Icon = meta.icon;
                return (
                  <motion.div
                    key={alert.id}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                  >
                    <Card className="overflow-hidden transition-shadow hover:shadow-lg">
                      <CardHeader className="pb-2">
                        <div className="flex flex-wrap items-start justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <div className={`flex h-9 w-9 items-center justify-center rounded-lg ${meta.color} bg-current/10`}>
                              <Icon className={`h-4 w-4 ${meta.color}`} />
                            </div>
                            <div>
                              <CardTitle className="text-base font-semibold">{alert.title}</CardTitle>
                              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                                <MapPin className="h-3 w-3" /> {alert.region}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={severityStyles[alert.severity]}>
                              {alert.severity}
                            </Badge>
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" /> {alert.timestamp}
                            </span>
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-3 pt-0">
                        <p className="text-sm text-muted-foreground">{alert.summary}</p>
                        <div className="rounded-lg border border-white/10 bg-white/[0.03] p-3 text-sm">
                          <span className="font-medium text-foreground">Recommendation: </span>
                          {alert.recommendation}
                        </div>
                        <p className="text-xs text-muted-foreground">Source: {alert.source}</p>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })
            )}
          </div>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Alerts;

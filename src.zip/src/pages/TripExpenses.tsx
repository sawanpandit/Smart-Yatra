import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import {
  Plus, DollarSign, ArrowLeft, Trash2, Edit, Download,
  Sparkles, Receipt, Users,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell,
} from "recharts";

const categories = ["Flights", "Hotels", "Food", "Transport", "Activities", "Shopping", "Other"];

const expenses = [
  { id: 1, description: "Flight SIN→DPS", category: "Flights", amount: 480, paidBy: "You", date: "Mar 10" },
  { id: 2, description: "The Mulia Resort deposit", category: "Hotels", amount: 250, paidBy: "You", date: "Mar 12" },
  { id: 3, description: "Airport transfer", category: "Transport", amount: 35, paidBy: "Sarah C.", date: "Mar 15" },
  { id: 4, description: "Dinner at Ku De Ta", category: "Food", amount: 120, paidBy: "James K.", date: "Mar 15" },
  { id: 5, description: "Ubud rice terrace tour", category: "Activities", amount: 105, paidBy: "You", date: "Mar 16" },
  { id: 6, description: "Scooter rental", category: "Transport", amount: 45, paidBy: "Sarah C.", date: "Mar 16" },
];

const budget = 2700;
const totalSpent = expenses.reduce((s, e) => s + e.amount, 0);

const categoryData = categories.map((cat) => ({
  name: cat,
  amount: expenses.filter((e) => e.category === cat).reduce((s, e) => s + e.amount, 0),
})).filter((c) => c.amount > 0);

const pieData = [
  { name: "Spent", value: totalSpent },
  { name: "Remaining", value: Math.max(budget - totalSpent, 0) },
];

const PIE_COLORS = ["hsl(224, 76%, 40%)", "hsl(214, 32%, 91%)"];

const participantSplits = [
  { name: "You", paid: 835, owes: 345 },
  { name: "Sarah C.", paid: 80, owes: 345 },
  { name: "James K.", paid: 120, owes: 345 },
];

const TripExpenses = () => {
  const { id } = useParams();
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <Layout>
      <div className="container py-8">
        {/* Header */}
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" asChild>
              <Link to={`/trips/${id}`}><ArrowLeft className="h-5 w-5" /></Link>
            </Button>
            <div>
              <h1 className="font-heading text-2xl font-bold">Trip Expenses</h1>
              <p className="text-sm text-muted-foreground">Bali, Indonesia</p>
            </div>
          </div>
          <div className="flex gap-2 self-start">
            <Button variant="outline" size="sm" className="gap-1"><Download className="h-3 w-3" /> Export</Button>
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm" className="gap-1"><Plus className="h-3 w-3" /> Add Expense</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader><DialogTitle>Add Expense</DialogTitle></DialogHeader>
                <div className="space-y-4 pt-2">
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Input placeholder="What was it for?" />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="space-y-2">
                      <Label>Amount ($)</Label>
                      <Input type="number" placeholder="0.00" />
                    </div>
                    <div className="space-y-2">
                      <Label>Category</Label>
                      <Select>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent>
                          {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Paid by</Label>
                    <Select>
                      <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="you">You</SelectItem>
                        <SelectItem value="sarah">Sarah C.</SelectItem>
                        <SelectItem value="james">James K.</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full" onClick={() => setDialogOpen(false)}>Add Expense</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Summary cards */}
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">Budget</p>
              <p className="font-heading text-xl font-bold">${budget.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">Spent</p>
              <p className="font-heading text-xl font-bold text-primary">${totalSpent.toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">Remaining</p>
              <p className="font-heading text-xl font-bold text-accent">${(budget - totalSpent).toLocaleString()}</p>
            </CardContent>
          </Card>
          <Card className="border-0 shadow-sm">
            <CardContent className="p-4">
              <p className="text-xs text-muted-foreground">Per Person</p>
              <p className="font-heading text-xl font-bold">${Math.round(totalSpent / 3).toLocaleString()}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main */}
          <div className="lg:col-span-2 space-y-6">
            {/* Charts */}
            <div className="grid gap-6 sm:grid-cols-2">
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2"><CardTitle className="font-heading text-base">By Category</CardTitle></CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={categoryData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                      <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip formatter={(v: number) => [`$${v}`, "Amount"]} contentStyle={{ borderRadius: "0.75rem", border: "none", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }} />
                      <Bar dataKey="amount" fill="hsl(224, 76%, 40%)" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
              <Card className="border-0 shadow-sm">
                <CardHeader className="pb-2"><CardTitle className="font-heading text-base">Budget Usage</CardTitle></CardHeader>
                <CardContent className="flex flex-col items-center">
                  <ResponsiveContainer width="100%" height={160}>
                    <PieChart>
                      <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={70} dataKey="value" strokeWidth={0}>
                        {pieData.map((_, idx) => <Cell key={idx} fill={PIE_COLORS[idx]} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => `$${v}`} />
                    </PieChart>
                  </ResponsiveContainer>
                  <p className="text-sm font-heading font-bold text-primary">{Math.round((totalSpent / budget) * 100)}% used</p>
                </CardContent>
              </Card>
            </div>

            {/* Expense list */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="font-heading text-base flex items-center gap-2"><Receipt className="h-4 w-4" /> All Expenses</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {expenses.map((e) => (
                    <div key={e.id} className="flex items-center justify-between rounded-lg p-3 hover:bg-muted/50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                          <DollarSign className="h-4 w-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium text-sm">{e.description}</p>
                          <div className="flex gap-2 text-xs text-muted-foreground">
                            <Badge variant="secondary" className="text-xs px-1.5 py-0">{e.category}</Badge>
                            <span>{e.paidBy} · {e.date}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-heading font-bold">${e.amount}</span>
                        <Button variant="ghost" size="icon" className="h-7 w-7"><Edit className="h-3 w-3" /></Button>
                        <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive"><Trash2 className="h-3 w-3" /></Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Participant splits */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="font-heading text-base flex items-center gap-2"><Users className="h-4 w-4" /> Split Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {participantSplits.map((p) => (
                  <div key={p.name} className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="flex h-7 w-7 items-center justify-center rounded-full bg-primary/10 font-heading font-semibold text-primary text-xs">{p.name[0]}</div>
                      <span className="font-medium">{p.name}</span>
                    </div>
                    <div className="text-right text-xs">
                      <p>Paid: <span className="font-semibold">${p.paid}</span></p>
                      <p className="text-muted-foreground">Owes: ${p.owes}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* AI budget */}
            <Card className="border-0 shadow-sm bg-gradient-to-br from-primary/5 to-accent/5">
              <CardContent className="p-4 text-center">
                <Sparkles className="mx-auto h-6 w-6 text-primary mb-2" />
                <p className="text-sm font-semibold mb-1">AI Budget Tips</p>
                <p className="text-xs text-muted-foreground mb-3">Get smart suggestions for optimizing your trip budget.</p>
                <Button size="sm" variant="outline" className="w-full gap-2">
                  <Sparkles className="h-3 w-3" /> Get Suggestions
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default TripExpenses;

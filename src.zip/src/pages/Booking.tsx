import { useState } from "react";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "@/hooks/use-toast";
import { motion } from "framer-motion";
import {
  Plane,
  Train,
  Bus,
  Car,
  Hotel,
  Search,
  ArrowRight,
  ArrowLeftRight,
  Calendar,
  Users,
  MapPin,
  Clock,
  SlidersHorizontal,
  Check,
} from "lucide-react";

// Mock data
const flights = [
  { id: 1, airline: "Singapore Airlines", code: "SQ-482", depart: "08:30", arrive: "13:45", duration: "5h 15m", stops: 0, price: 480, class: "Economy" },
  { id: 2, airline: "Garuda Indonesia", code: "GA-215", depart: "10:00", arrive: "16:30", duration: "6h 30m", stops: 1, price: 350, class: "Economy" },
  { id: 3, airline: "Emirates", code: "EK-358", depart: "23:55", arrive: "09:20", duration: "9h 25m", stops: 1, price: 520, class: "Economy" },
];

const trains = [
  { id: 1, name: "Rajdhani Express", number: "12301", from: "New Delhi", to: "Mumbai", depart: "16:25", arrive: "08:15", duration: "15h 50m", price: 2450, class: "AC 2 Tier" },
  { id: 2, name: "Shatabdi Express", number: "12002", from: "New Delhi", to: "Lucknow", depart: "06:00", arrive: "12:05", duration: "6h 5m", price: 890, class: "Chair Car" },
  { id: 3, name: "Duronto Express", number: "12259", from: "Mumbai", to: "Ahmedabad", depart: "23:45", arrive: "06:30", duration: "6h 45m", price: 520, class: "Sleeper" },
];

const buses = [
  { id: 1, operator: "Volvo AC", from: "Bangalore", to: "Chennai", depart: "22:00", arrive: "05:30", duration: "7h 30m", price: 650, seats: "2+1" },
  { id: 2, operator: "Sleeper Bus", from: "Mumbai", to: "Goa", depart: "23:00", arrive: "08:00", duration: "9h", price: 899, seats: "2+1" },
  { id: 3, operator: "Luxury Coach", from: "Delhi", to: "Jaipur", depart: "06:00", arrive: "10:30", duration: "4h 30m", price: 450, seats: "2+2" },
];

const cabOptions = [
  { id: 1, type: "Mini", car: "Swift / Etios", pricePerKm: 12, minFare: 80, eta: "3 min" },
  { id: 2, type: "Sedan", car: "Dzire / Xcent", pricePerKm: 14, minFare: 100, eta: "5 min" },
  { id: 3, type: "SUV", car: "Innova / Ertiga", pricePerKm: 18, minFare: 150, eta: "7 min" },
];

const hotels = [
  { id: 1, name: "The Mulia Resort & Villas", image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=400&h=250&fit=crop", rating: 4.9, reviews: 1240, price: 320, amenities: ["Pool", "Spa", "WiFi"], location: "Nusa Dua, Bali" },
  { id: 2, name: "Alila Villas Uluwatu", image: "https://images.unsplash.com/photo-1582719508461-905c673771fd?w=400&h=250&fit=crop", rating: 4.8, reviews: 890, price: 450, amenities: ["Pool", "Ocean View", "WiFi"], location: "Uluwatu, Bali" },
  { id: 3, name: "Ubud Village Resort", image: "https://images.unsplash.com/photo-1540541338287-41700207dee6?w=400&h=250&fit=crop", rating: 4.5, reviews: 650, price: 85, amenities: ["Pool", "WiFi", "Breakfast"], location: "Ubud, Bali" },
];

const Booking = () => {
  const [activeTab, setActiveTab] = useState("flights");
  const [selectedFlight, setSelectedFlight] = useState<number | null>(null);
  const [selectedTrain, setSelectedTrain] = useState<number | null>(null);
  const [selectedBus, setSelectedBus] = useState<number | null>(null);
  const [selectedCab, setSelectedCab] = useState<number | null>(null);
  const [selectedHotel, setSelectedHotel] = useState<number | null>(null);
  const [cabPickup, setCabPickup] = useState("");
  const [cabDrop, setCabDrop] = useState("");
  const [cabDate, setCabDate] = useState("");
  const [, setBookingConfirmed] = useState<string | null>(null);

  const handleConfirmFlight = () => {
    if (!selectedFlight) return;
    setBookingConfirmed("flight");
    toast({ title: "Flight booked!", description: `Booking confirmed for ${flights.find((f) => f.id === selectedFlight)?.airline}. Confirmation sent to your email.` });
  };

  const handleConfirmTrain = () => {
    if (!selectedTrain) return;
    setBookingConfirmed("train");
    toast({ title: "Train ticket booked!", description: `PNR will be sent to your mobile. ${trains.find((t) => t.id === selectedTrain)?.name} ${trains.find((t) => t.id === selectedTrain)?.number}` });
  };

  const handleConfirmBus = () => {
    if (!selectedBus) return;
    setBookingConfirmed("bus");
    toast({ title: "Bus ticket booked!", description: `E-ticket for ${buses.find((b) => b.id === selectedBus)?.operator} has been sent to your email.` });
  };

  const handleConfirmCab = () => {
    if (!selectedCab) return;
    setBookingConfirmed("cab");
    const cab = cabOptions.find((c) => c.id === selectedCab)!;
    const estKm = 15;
    const fare = Math.max(cab.minFare, cab.pricePerKm * estKm);
    toast({ title: "Cab booked!", description: `${cab.type} is on the way. Estimated fare: ₹${fare}. Driver will call you shortly.` });
  };

  const handleConfirmHotel = () => {
    if (!selectedHotel) return;
    setBookingConfirmed("hotel");
    const h = hotels.find((x) => x.id === selectedHotel)!;
    toast({ title: "Hotel booked!", description: `${h.name} — confirmation and check-in details sent to your email.` });
  };

  return (
    <Layout>
      <div className="container py-8">
        <div className="mb-6 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-heading text-3xl font-bold">Book Your Travel</h1>
            <p className="text-muted-foreground">Flights, trains, buses, cabs & hotels — all in one place.</p>
          </div>
          <Button variant="outline" size="sm" asChild>
            <Link to="/dashboard">Back to Dashboard</Link>
          </Button>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5 h-auto gap-1 p-1 bg-muted/50">
            <TabsTrigger value="flights" className="gap-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Plane className="h-4 w-4" /> Flights
            </TabsTrigger>
            <TabsTrigger value="trains" className="gap-2">
              <Train className="h-4 w-4" /> Trains
            </TabsTrigger>
            <TabsTrigger value="buses" className="gap-2">
              <Bus className="h-4 w-4" /> Buses
            </TabsTrigger>
            <TabsTrigger value="cab" className="gap-2">
              <Car className="h-4 w-4" /> Cab
            </TabsTrigger>
            <TabsTrigger value="hotels" className="gap-2">
              <Hotel className="h-4 w-4" /> Hotels
            </TabsTrigger>
          </TabsList>

          {/* Flights */}
          <TabsContent value="flights" className="space-y-6 mt-0">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                  <div className="space-y-2">
                    <Label>From</Label>
                    <Input placeholder="e.g. Delhi (DEL)" />
                  </div>
                  <div className="space-y-2">
                    <Label>To</Label>
                    <Input placeholder="e.g. Mumbai (BOM)" />
                  </div>
                  <div className="space-y-2">
                    <Label>Departure</Label>
                    <Input type="date" defaultValue="2026-03-15" />
                  </div>
                  <div className="space-y-2">
                    <Label>Return</Label>
                    <Input type="date" defaultValue="2026-03-22" />
                  </div>
                  <div className="space-y-2">
                    <Label>Passengers</Label>
                    <Select defaultValue="1">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5].map((n) => (
                          <SelectItem key={n} value={String(n)}>{n} Passenger{n > 1 ? "s" : ""}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Flights</Button>
              </CardContent>
            </Card>
            <div className="space-y-3">
              {flights.map((f, i) => (
                <motion.div key={f.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card
                    className={`cursor-pointer border-0 shadow-sm transition-all hover:shadow-md ${selectedFlight === f.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedFlight(f.id)}
                  >
                    <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Plane className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-heading font-semibold text-sm">{f.airline}</p>
                          <p className="text-xs text-muted-foreground">{f.code} · {f.class}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6 text-sm">
                        <div className="text-center">
                          <p className="font-heading font-bold">{f.depart}</p>
                          <p className="text-xs text-muted-foreground">DEP</p>
                        </div>
                        <div className="flex flex-col items-center">
                          <p className="text-xs text-muted-foreground">{f.duration}</p>
                          <div className="flex items-center gap-1">
                            <div className="h-px w-16 bg-border" />
                            <Plane className="h-3 w-3 text-muted-foreground" />
                          </div>
                          <p className="text-xs text-muted-foreground">{f.stops === 0 ? "Direct" : `${f.stops} stop`}</p>
                        </div>
                        <div className="text-center">
                          <p className="font-heading font-bold">{f.arrive}</p>
                          <p className="text-xs text-muted-foreground">ARR</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-heading text-xl font-bold text-primary">₹{f.price}</p>
                        <p className="text-xs text-muted-foreground">per person</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            {selectedFlight && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-heading font-semibold text-lg mb-4">Complete your flight booking</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2"><Label>Full Name</Label><Input placeholder="As on ID" /></div>
                    <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
                    <div className="space-y-2"><Label>Mobile</Label><Input placeholder="10-digit number" /></div>
                    <div className="space-y-2"><Label>ID Number</Label><Input placeholder="Aadhaar / Passport" /></div>
                  </div>
                  <Button className="mt-6 gap-2" size="lg" onClick={handleConfirmFlight}>
                    <Check className="h-4 w-4" /> Confirm — ₹{flights.find((x) => x.id === selectedFlight)?.price}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Trains */}
          <TabsContent value="trains" className="space-y-6 mt-0">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="space-y-2"><Label>From Station</Label><Input placeholder="e.g. New Delhi (NDLS)" /></div>
                  <div className="space-y-2"><Label>To Station</Label><Input placeholder="e.g. Mumbai Central (MMCT)" /></div>
                  <div className="space-y-2"><Label>Date of Journey</Label><Input type="date" defaultValue="2026-03-20" /></div>
                  <div className="space-y-2">
                    <Label>Class</Label>
                    <Select defaultValue="all">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Classes</SelectItem>
                        <SelectItem value="ac1">AC 1 Tier</SelectItem>
                        <SelectItem value="ac2">AC 2 Tier</SelectItem>
                        <SelectItem value="ac3">AC 3 Tier</SelectItem>
                        <SelectItem value="sleeper">Sleeper</SelectItem>
                        <SelectItem value="cc">Chair Car</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Trains</Button>
              </CardContent>
            </Card>
            <div className="space-y-3">
              {trains.map((t, i) => (
                <motion.div key={t.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card
                    className={`cursor-pointer border-0 shadow-sm transition-all hover:shadow-md ${selectedTrain === t.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedTrain(t.id)}
                  >
                    <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Train className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-heading font-semibold text-sm">{t.name}</p>
                          <p className="text-xs text-muted-foreground">{t.number} · {t.class}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6 text-sm">
                        <div className="text-center">
                          <p className="font-heading font-bold">{t.depart}</p>
                          <p className="text-xs text-muted-foreground">{t.from}</p>
                        </div>
                        <div className="flex flex-col items-center">
                          <p className="text-xs text-muted-foreground">{t.duration}</p>
                          <div className="flex items-center gap-1">
                            <div className="h-px w-16 bg-border" />
                            <Train className="h-3 w-3 text-muted-foreground" />
                          </div>
                        </div>
                        <div className="text-center">
                          <p className="font-heading font-bold">{t.arrive}</p>
                          <p className="text-xs text-muted-foreground">{t.to}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-heading text-xl font-bold text-primary">₹{t.price}</p>
                        <p className="text-xs text-muted-foreground">per seat</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            {selectedTrain && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-heading font-semibold text-lg mb-4">Complete your train booking</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2"><Label>Passenger Name</Label><Input placeholder="As on ID" /></div>
                    <div className="space-y-2"><Label>Age</Label><Input type="number" placeholder="Age" /></div>
                    <div className="space-y-2"><Label>Mobile</Label><Input placeholder="10-digit number" /></div>
                    <div className="space-y-2"><Label>ID (Aadhaar/PAN)</Label><Input placeholder="ID number" /></div>
                  </div>
                  <Button className="mt-6 gap-2" size="lg" onClick={handleConfirmTrain}>
                    <Check className="h-4 w-4" /> Confirm — ₹{trains.find((x) => x.id === selectedTrain)?.price}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Buses */}
          <TabsContent value="buses" className="space-y-6 mt-0">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="space-y-2"><Label>From</Label><Input placeholder="City or bus stand" /></div>
                  <div className="space-y-2"><Label>To</Label><Input placeholder="City or bus stand" /></div>
                  <div className="space-y-2"><Label>Date</Label><Input type="date" defaultValue="2026-03-18" /></div>
                  <div className="space-y-2">
                    <Label>Seats</Label>
                    <Select defaultValue="1">
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {[1, 2, 3, 4, 5].map((n) => (
                          <SelectItem key={n} value={String(n)}>{n} Seat{n > 1 ? "s" : ""}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Buses</Button>
              </CardContent>
            </Card>
            <div className="space-y-3">
              {buses.map((b, i) => (
                <motion.div key={b.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card
                    className={`cursor-pointer border-0 shadow-sm transition-all hover:shadow-md ${selectedBus === b.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedBus(b.id)}
                  >
                    <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Bus className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-heading font-semibold text-sm">{b.operator}</p>
                          <p className="text-xs text-muted-foreground">Seating: {b.seats}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-6 text-sm">
                        <div className="text-center">
                          <p className="font-heading font-bold">{b.depart}</p>
                          <p className="text-xs text-muted-foreground">{b.from}</p>
                        </div>
                        <div className="flex flex-col items-center">
                          <p className="text-xs text-muted-foreground">{b.duration}</p>
                          <div className="flex items-center gap-1">
                            <div className="h-px w-16 bg-border" />
                            <Bus className="h-3 w-3 text-muted-foreground" />
                          </div>
                        </div>
                        <div className="text-center">
                          <p className="font-heading font-bold">{b.arrive}</p>
                          <p className="text-xs text-muted-foreground">{b.to}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-heading text-xl font-bold text-primary">₹{b.price}</p>
                        <p className="text-xs text-muted-foreground">per seat</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            {selectedBus && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-heading font-semibold text-lg mb-4">Complete your bus booking</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2"><Label>Passenger Name</Label><Input placeholder="Full name" /></div>
                    <div className="space-y-2"><Label>Mobile</Label><Input placeholder="10-digit number" /></div>
                    <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
                    <div className="space-y-2"><Label>Boarding Point</Label><Select><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger><SelectContent><SelectItem value="1">Main bus stand</SelectItem><SelectItem value="2">City center</SelectItem></SelectContent></Select></div>
                  </div>
                  <Button className="mt-6 gap-2" size="lg" onClick={handleConfirmBus}>
                    <Check className="h-4 w-4" /> Confirm — ₹{buses.find((x) => x.id === selectedBus)?.price}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Cab */}
          <TabsContent value="cab" className="space-y-6 mt-0">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="space-y-2">
                    <Label>Pickup</Label>
                    <Input placeholder="Address or landmark" value={cabPickup} onChange={(e) => setCabPickup(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Drop</Label>
                    <Input placeholder="Address or landmark" value={cabDrop} onChange={(e) => setCabDrop(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label>Date & Time</Label>
                    <Input type="datetime-local" value={cabDate} onChange={(e) => setCabDate(e.target.value)} />
                  </div>
                  <div className="flex items-end">
                    <Button className="gap-2 w-full"><Search className="h-4 w-4" /> Get cabs</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            <p className="text-sm text-muted-foreground">Choose your ride (fare is estimated for ~15 km)</p>
            <div className="grid gap-3 sm:grid-cols-3">
              {cabOptions.map((c, i) => (
                <motion.div key={c.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card
                    className={`cursor-pointer border-0 shadow-sm transition-all hover:shadow-md ${selectedCab === c.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedCab(c.id)}
                  >
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <Car className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="font-heading font-semibold">{c.type}</p>
                          <p className="text-xs text-muted-foreground">{c.car}</p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mb-1"><Clock className="h-3 w-3" /> ETA {c.eta}</p>
                      <p className="font-heading text-lg font-bold text-primary">₹{Math.max(c.minFare, c.pricePerKm * 15)} <span className="text-xs font-normal text-muted-foreground">est.</span></p>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            {selectedCab && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-heading font-semibold text-lg mb-4">Confirm your cab</h3>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2"><Label>Name</Label><Input placeholder="Your name" /></div>
                    <div className="space-y-2"><Label>Mobile</Label><Input placeholder="10-digit number" /></div>
                  </div>
                  <Button className="mt-6 gap-2" size="lg" onClick={handleConfirmCab}>
                    <Check className="h-4 w-4" /> Book {cabOptions.find((x) => x.id === selectedCab)?.type} — Est. ₹{Math.max(cabOptions.find((x) => x.id === selectedCab)!.minFare, cabOptions.find((x) => x.id === selectedCab)!.pricePerKm * 15)}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Hotels */}
          <TabsContent value="hotels" className="space-y-6 mt-0">
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                  <div className="space-y-2"><Label>Destination</Label><Input placeholder="City or hotel name" /></div>
                  <div className="space-y-2"><Label>Check-in</Label><Input type="date" defaultValue="2026-03-15" /></div>
                  <div className="space-y-2"><Label>Check-out</Label><Input type="date" defaultValue="2026-03-22" /></div>
                  <div className="space-y-2">
                    <Label>Guests</Label>
                    <Select defaultValue="2"><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1, 2, 3, 4].map((n) => <SelectItem key={n} value={String(n)}>{n} Guest{n > 1 ? "s" : ""}</SelectItem>)}</SelectContent></Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Rooms</Label>
                    <Select defaultValue="1"><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1, 2, 3].map((n) => <SelectItem key={n} value={String(n)}>{n} Room{n > 1 ? "s" : ""}</SelectItem>)}</SelectContent></Select>
                  </div>
                </div>
                <Button className="mt-4 gap-2"><Search className="h-4 w-4" /> Search Hotels</Button>
              </CardContent>
            </Card>
            <div className="space-y-4">
              {hotels.map((h, i) => (
                <motion.div key={h.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                  <Card className="group overflow-hidden border-0 shadow-sm transition-all hover:shadow-md">
                    <CardContent className="flex flex-col gap-4 p-0 sm:flex-row">
                      <div className="relative h-48 w-full overflow-hidden sm:h-auto sm:w-64 shrink-0">
                        <img src={h.image} alt={h.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" loading="lazy" />
                      </div>
                      <div className="flex flex-1 flex-col justify-between p-5">
                        <div>
                          <div className="flex items-start justify-between mb-1">
                            <h3 className="font-heading font-semibold text-lg">{h.name}</h3>
                            <div className="flex items-center gap-1 text-sm shrink-0">
                              <span className="font-semibold">{h.rating}</span>
                              <span className="text-xs text-muted-foreground">({h.reviews})</span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground flex items-center gap-1 mb-3"><MapPin className="h-3 w-3" /> {h.location}</p>
                          <div className="flex flex-wrap gap-2">
                            {h.amenities.map((a) => (
                              <Badge key={a} variant="secondary" className="text-xs rounded-full">{a}</Badge>
                            ))}
                          </div>
                        </div>
                        <div className="mt-4 flex items-end justify-between">
                          <div>
                            <span className="font-heading text-2xl font-bold text-primary">₹{h.price}</span>
                            <span className="text-sm text-muted-foreground">/night</span>
                          </div>
                          <Button
                            className="gap-2"
                            variant={selectedHotel === h.id ? "default" : "outline"}
                            onClick={() => setSelectedHotel(selectedHotel === h.id ? null : h.id)}
                          >
                            <Hotel className="h-4 w-4" /> {selectedHotel === h.id ? "Selected" : "Select"}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
            {selectedHotel && (
              <Card className="border-0 shadow-lg">
                <CardContent className="p-6">
                  <h3 className="font-heading font-semibold text-lg mb-4">Complete your hotel booking</h3>
                  <div className="rounded-lg bg-muted/50 p-3 flex items-center justify-between text-sm mb-4">
                    <span>7 nights × ₹{hotels.find((x) => x.id === selectedHotel)?.price}/night</span>
                    <span className="font-heading font-bold text-primary">₹{(hotels.find((x) => x.id === selectedHotel)?.price ?? 0) * 7}</span>
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="space-y-2"><Label>First Name</Label><Input placeholder="John" /></div>
                    <div className="space-y-2"><Label>Last Name</Label><Input placeholder="Doe" /></div>
                    <div className="space-y-2 sm:col-span-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
                    <div className="space-y-2 sm:col-span-2"><Label>Special Requests</Label><Input placeholder="Late check-in, extra pillows..." /></div>
                  </div>
                  <Button className="mt-6 gap-2" size="lg" onClick={handleConfirmHotel}>
                    <Check className="h-4 w-4" /> Confirm — ₹{(hotels.find((x) => x.id === selectedHotel)?.price ?? 0) * 7}
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Booking;

import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { Copy, Share2, Gift, Users, Check, DollarSign, ArrowRight } from "lucide-react";
import { toast } from "@/hooks/use-toast";

const referralCode = "SMARTYATRA-X7K9";

const referrals = [
  { name: "Emma Wilson", status: "completed", reward: 100, date: "Feb 18" },
  { name: "David Park", status: "pending", reward: 0, date: "Feb 22" },
  { name: "Ana Garcia", status: "completed", reward: 100, date: "Jan 30" },
];

const Referrals = () => {
  const copyCode = () => {
    navigator.clipboard.writeText(referralCode);
    toast({ title: "Copied!", description: "Referral code copied to clipboard." });
  };

  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        <h1 className="font-heading text-3xl font-bold mb-2">Referral Program</h1>
        <p className="text-muted-foreground mb-8">Invite friends and earn rewards together!</p>

        {/* Referral code */}
        <Card className="border-0 shadow-sm bg-gradient-to-br from-primary/5 to-accent/5 mb-6">
          <CardContent className="p-6 text-center">
            <Gift className="mx-auto h-10 w-10 text-primary mb-3" />
            <h2 className="font-heading text-lg font-bold mb-1">Your Referral Code</h2>
            <div className="mx-auto mt-3 flex max-w-sm items-center gap-2 rounded-xl bg-card p-2 shadow-sm">
              <Input value={referralCode} readOnly className="text-center font-heading font-bold border-0 bg-transparent" />
              <Button size="icon" variant="ghost" onClick={copyCode}><Copy className="h-4 w-4" /></Button>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">Earn <strong>100 points</strong> for every friend who signs up and completes a booking.</p>
            <div className="mt-4 flex justify-center gap-2">
              <Button variant="outline" size="sm" className="gap-1"><Share2 className="h-3 w-3" /> Share Link</Button>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="mb-6 grid grid-cols-3 gap-3">
          <Card className="border-0 shadow-sm"><CardContent className="p-4 text-center"><p className="font-heading text-2xl font-bold text-primary">3</p><p className="text-xs text-muted-foreground">Total Referrals</p></CardContent></Card>
          <Card className="border-0 shadow-sm"><CardContent className="p-4 text-center"><p className="font-heading text-2xl font-bold text-accent">2</p><p className="text-xs text-muted-foreground">Completed</p></CardContent></Card>
          <Card className="border-0 shadow-sm"><CardContent className="p-4 text-center"><p className="font-heading text-2xl font-bold">200</p><p className="text-xs text-muted-foreground">Points Earned</p></CardContent></Card>
        </div>

        {/* Referral history */}
        <Card className="border-0 shadow-sm">
          <CardContent className="p-4">
            <h3 className="font-heading font-semibold mb-3">Referral History</h3>
            {referrals.map((r, i) => (
              <div key={i} className={`flex items-center justify-between py-3 ${i < referrals.length - 1 ? "border-b border-border" : ""}`}>
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 font-heading font-semibold text-primary text-xs">{r.name[0]}</div>
                  <div>
                    <p className="font-medium text-sm">{r.name}</p>
                    <p className="text-xs text-muted-foreground">{r.date}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={r.status === "completed" ? "default" : "secondary"} className={`text-xs capitalize ${r.status === "completed" ? "bg-accent/10 text-accent" : ""}`}>
                    {r.status}
                  </Badge>
                  {r.reward > 0 && <span className="text-xs font-semibold text-accent">+{r.reward} pts</span>}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </Layout>
  );
};

export default Referrals;

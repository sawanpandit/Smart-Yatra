import { useState } from "react";
import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { motion } from "framer-motion";
import {
  Plus, MapPin, Calendar, Clock, Sparkles, GripVertical,
  Trash2, Save, Share2, ArrowRight,
} from "lucide-react";

const sampleActivities = [
  { id: 1, name: "Tegallalang Rice Terraces", duration: "3h", time: "08:00" },
  { id: 2, name: "Lunch at Locavore", duration: "1.5h", time: "11:30" },
  { id: 3, name: "Sacred Monkey Forest", duration: "2h", time: "14:00" },
  { id: 4, name: "Sunset at Uluwatu Temple", duration: "2h", time: "17:00" },
];

const ItineraryCreate = () => {
  const [step, setStep] = useState(1);
  const [destination, setDestination] = useState("");
  const [days, setDays] = useState(3);

  return (
    <Layout>
      <div className="container max-w-3xl py-8">
        <h1 className="font-heading text-3xl font-bold mb-2">Create Itinerary</h1>
        <p className="text-muted-foreground mb-8">Plan your perfect trip step by step.</p>

        {/* Progress */}
        <div className="mb-8 flex items-center gap-2">
          {[1, 2, 3].map((s) => (
            <div key={s} className="flex items-center gap-2">
              <div className={`flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold transition-colors ${
                s <= step ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
              }`}>{s}</div>
              {s < 3 && <div className={`h-0.5 w-12 ${s < step ? "bg-primary" : "bg-border"}`} />}
            </div>
          ))}
          <div className="ml-4 text-sm text-muted-foreground">
            {step === 1 && "Trip Details"}
            {step === 2 && "Plan Activities"}
            {step === 3 && "Review & Save"}
          </div>
        </div>

        {/* Step 1: Trip Details */}
        {step === 1 && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="space-y-2">
                  <Label>Destination</Label>
                  <Input placeholder="Where are you going?" value={destination} onChange={(e) => setDestination(e.target.value)} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Start Date</Label><Input type="date" defaultValue="2026-03-15" /></div>
                  <div className="space-y-2"><Label>End Date</Label><Input type="date" defaultValue="2026-03-18" /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Number of Days</Label>
                    <Select value={String(days)} onValueChange={(v) => setDays(Number(v))}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>{[1,2,3,4,5,6,7,10,14].map(n=><SelectItem key={n} value={String(n)}>{n} days</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Travelers</Label>
                    <Select defaultValue="2"><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{[1,2,3,4,5,6].map(n=><SelectItem key={n} value={String(n)}>{n}</SelectItem>)}</SelectContent></Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Budget ($)</Label>
                  <Input type="number" placeholder="2000" />
                </div>
                <div className="flex gap-3 pt-2">
                  <Button onClick={() => setStep(2)} className="gap-2">
                    Continue <ArrowRight className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <Sparkles className="h-4 w-4" /> AI Auto-Plan
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Step 2: Activities */}
        {step === 2 && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
            {Array.from({ length: Math.min(days, 3) }, (_, dayIdx) => (
              <Card key={dayIdx} className="border-0 shadow-sm">
                <CardHeader className="pb-2">
                  <CardTitle className="font-heading text-base flex items-center gap-2">
                    <Badge variant="secondary">Day {dayIdx + 1}</Badge>
                    {destination || "Your Destination"}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {(dayIdx === 0 ? sampleActivities : sampleActivities.slice(0, 2)).map((a) => (
                    <div key={a.id} className="flex items-center gap-3 rounded-lg border border-border p-3 bg-card">
                      <GripVertical className="h-4 w-4 text-muted-foreground cursor-grab shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{a.name}</p>
                        <div className="flex gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {a.time}</span>
                          <span>{a.duration}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive shrink-0">
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                  <Button variant="outline" size="sm" className="w-full gap-1 mt-2">
                    <Plus className="h-3 w-3" /> Add Activity
                  </Button>
                </CardContent>
              </Card>
            ))}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
              <Button onClick={() => setStep(3)} className="gap-2">Review <ArrowRight className="h-4 w-4" /></Button>
              <Button variant="outline" className="gap-2 ml-auto">
                <Sparkles className="h-4 w-4" /> AI Optimize
              </Button>
            </div>
          </motion.div>
        )}

        {/* Step 3: Review */}
        {step === 3 && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6 space-y-4">
                <div className="rounded-lg bg-muted/50 p-4 space-y-2">
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">Destination</span><span className="font-semibold">{destination || "Bali, Indonesia"}</span></div>
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">Duration</span><span className="font-semibold">{days} days</span></div>
                  <div className="flex justify-between text-sm"><span className="text-muted-foreground">Activities</span><span className="font-semibold">{sampleActivities.length + 2} planned</span></div>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
                  <Button className="gap-2"><Save className="h-4 w-4" /> Save Itinerary</Button>
                  <Button variant="outline" className="gap-2"><Share2 className="h-4 w-4" /> Share</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </Layout>
  );
};

export default ItineraryCreate;

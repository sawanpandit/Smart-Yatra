import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Plane, MailCheck, RefreshCw } from "lucide-react";

const VerifyEmail = () => {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-primary/5 via-background to-accent/5 p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary">
            <Plane className="h-6 w-6 text-primary-foreground" />
          </div>
          <span className="font-heading text-2xl font-bold">Smart Yatra</span>
        </Link>

        <Card className="border-0 shadow-xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-accent/10">
              <MailCheck className="h-8 w-8 text-accent" />
            </div>
            <CardTitle className="font-heading text-2xl">Check your email</CardTitle>
            <CardDescription>
              We've sent a verification link to your email address. Please click the link to verify your account.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full gap-2">
              <RefreshCw className="h-4 w-4" /> Resend Verification Email
            </Button>
            <p className="text-center text-sm text-muted-foreground">
              Didn't receive the email? Check your spam folder or{" "}
              <Link to="/help" className="text-primary hover:underline">contact support</Link>.
            </p>
            <div className="pt-2 text-center">
              <Link to="/auth/login" className="text-sm font-semibold text-primary hover:underline">
                Back to Sign In
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default VerifyEmail;

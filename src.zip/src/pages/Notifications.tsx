import { useState } from "react";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Bell, Plane, Hotel, Users, CloudSun, Check, Trash2, CheckCheck,
} from "lucide-react";

const notifications = [
  { id: 1, type: "booking", title: "Flight Confirmed", desc: "Your SQ-482 to Bali is confirmed.", time: "2h ago", read: false },
  { id: 2, type: "alert", title: "Weather Alert", desc: "Heavy rain expected in Paris next week.", time: "5h ago", read: false },
  { id: 3, type: "social", title: "Friend Request", desc: "Alex Johnson wants to connect with you.", time: "1d ago", read: true },
  { id: 4, type: "booking", title: "Hotel Booked", desc: "The Mulia Resort reservation confirmed.", time: "1d ago", read: true },
  { id: 5, type: "social", title: "Trip Invitation", desc: "Sarah invited you to the Tokyo trip.", time: "2d ago", read: true },
  { id: 6, type: "alert", title: "Price Drop", desc: "Dubai flights dropped 20% since you searched.", time: "3d ago", read: true },
];

const iconMap = { booking: Plane, alert: CloudSun, social: Users };

const Notifications = () => {
  const [items, setItems] = useState(notifications);
  const [tab, setTab] = useState("all");

  const filtered = items.filter((n) => tab === "all" || n.type === tab);
  const unread = items.filter((n) => !n.read).length;

  const markAllRead = () => setItems((prev) => prev.map((n) => ({ ...n, read: true })));
  const deleteNotif = (id: number) => setItems((prev) => prev.filter((n) => n.id !== id));

  return (
    <Layout>
      <div className="container max-w-2xl py-8">
        <div className="mb-6 flex items-center justify-between">
          <div>
            <h1 className="font-heading text-3xl font-bold">Notifications</h1>
            <p className="text-muted-foreground">{unread} unread</p>
          </div>
          <Button variant="outline" size="sm" className="gap-1" onClick={markAllRead}>
            <CheckCheck className="h-3 w-3" /> Mark all read
          </Button>
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="booking">Bookings</TabsTrigger>
            <TabsTrigger value="alert">Alerts</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
          </TabsList>

          <TabsContent value={tab} className="mt-4 space-y-2">
            {filtered.length === 0 && (
              <div className="py-12 text-center text-muted-foreground">
                <Bell className="mx-auto h-10 w-10 mb-3 opacity-50" />
                <p>No notifications in this category.</p>
              </div>
            )}
            {filtered.map((n) => {
              const Icon = iconMap[n.type as keyof typeof iconMap] || Bell;
              return (
                <Card key={n.id} className={`border-0 shadow-sm transition-colors ${!n.read ? "bg-primary/[0.03]" : ""}`}>
                  <CardContent className="flex items-start gap-3 p-4">
                    <div className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${!n.read ? "bg-primary/10" : "bg-muted"}`}>
                      <Icon className={`h-4 w-4 ${!n.read ? "text-primary" : "text-muted-foreground"}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className={`text-sm ${!n.read ? "font-semibold" : "font-medium"}`}>{n.title}</p>
                        {!n.read && <span className="h-2 w-2 rounded-full bg-primary" />}
                      </div>
                      <p className="text-xs text-muted-foreground">{n.desc}</p>
                      <p className="text-xs text-muted-foreground mt-1">{n.time}</p>
                    </div>
                    <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0 text-muted-foreground" onClick={() => deleteNotif(n.id)}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </TabsContent>
        </Tabs>
      </div>
    </Layout>
  );
};

export default Notifications;

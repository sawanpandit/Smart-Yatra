import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  MapPin, Star, CloudSun, AlertTriangle, Calendar, DollarSign,
  Plane, Hotel, Share2, Heart, Clock, ChevronLeft, ChevronRight,
  Sparkles, Users, Camera,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const dest = {
  id: "1",
  name: "Bali, Indonesia",
  country: "Indonesia",
  description: "Bali is a living postcard, an Indonesian paradise that feels like a fantasy. Soak up the sun on a stretch of fine white sand, or commune with the tropical creatures as you dive along coral ridges.",
  images: [
    "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=900&h=500&fit=crop",
    "https://images.unsplash.com/photo-1555400038-63f5ba517a47?w=900&h=500&fit=crop",
    "https://images.unsplash.com/photo-1573790387438-4da905039392?w=900&h=500&fit=crop",
  ],
  rating: 4.8,
  reviews: 2340,
  highlights: ["Tropical Beaches", "Ancient Temples", "Rice Terraces", "Diving & Snorkeling", "Cultural Experiences"],
  weather: { temp: "29°C", condition: "Sunny", humidity: "75%", bestMonths: "Apr-Oct" },
  alerts: [{ type: "info", message: "Rainy season begins November — plan accordingly." }],
  activities: [
    { name: "Uluwatu Temple Visit", duration: "3h", price: 25, rating: 4.9 },
    { name: "Ubud Rice Terrace Trek", duration: "4h", price: 35, rating: 4.8 },
    { name: "Nusa Penida Snorkeling", duration: "6h", price: 60, rating: 4.7 },
    { name: "Traditional Cooking Class", duration: "3h", price: 40, rating: 4.9 },
  ],
  hotels: [
    { name: "The Mulia Resort", price: 320, rating: 4.9 },
    { name: "Alila Villas Uluwatu", price: 450, rating: 4.8 },
    { name: "Ubud Village Hotel", price: 85, rating: 4.5 },
  ],
  reviews_list: [
    { user: "Alex M.", rating: 5, text: "Absolutely magical! The temples and rice terraces were breathtaking.", date: "Feb 2026" },
    { user: "Maria L.", rating: 4, text: "Beautiful destination. Can get crowded at popular spots but still worth it.", date: "Jan 2026" },
    { user: "James K.", rating: 5, text: "Best trip of my life. The people, food, and scenery are incredible.", date: "Dec 2025" },
  ],
};

const DestinationDetails = () => {
  const { id } = useParams();
  const [currentImage, setCurrentImage] = useState(0);
  const [saved, setSaved] = useState(false);

  const nextImage = () => setCurrentImage((i) => (i + 1) % dest.images.length);
  const prevImage = () => setCurrentImage((i) => (i - 1 + dest.images.length) % dest.images.length);

  return (
    <Layout>
      <div className="container py-8">
        {/* Breadcrumb */}
        <div className="mb-4 flex items-center gap-2 text-sm text-muted-foreground">
          <Link to="/search" className="hover:text-foreground">Destinations</Link>
          <span>/</span>
          <span className="text-foreground">{dest.name}</span>
        </div>

        {/* Hero Gallery */}
        <div className="relative mb-8 overflow-hidden rounded-2xl">
          <motion.img
            key={currentImage}
            src={dest.images[currentImage]}
            alt={dest.name}
            className="h-[300px] w-full object-cover sm:h-[420px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
          <Button variant="ghost" size="icon" className="absolute left-3 top-1/2 -translate-y-1/2 bg-card/80 hover:bg-card" onClick={prevImage}>
            <ChevronLeft className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="absolute right-3 top-1/2 -translate-y-1/2 bg-card/80 hover:bg-card" onClick={nextImage}>
            <ChevronRight className="h-5 w-5" />
          </Button>
          <div className="absolute bottom-4 left-4 right-4 flex items-end justify-between">
            <div>
              <h1 className="font-heading text-3xl font-bold text-white sm:text-4xl">{dest.name}</h1>
              <div className="mt-1 flex items-center gap-3 text-white/90 text-sm">
                <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-secondary text-secondary" /> {dest.rating}</span>
                <span>({dest.reviews} reviews)</span>
              </div>
            </div>
            <div className="flex gap-2">
              <Button size="icon" variant="ghost" className="bg-card/80 hover:bg-card" onClick={() => setSaved(!saved)}>
                <Heart className={`h-5 w-5 ${saved ? "fill-destructive text-destructive" : ""}`} />
              </Button>
              <Button size="icon" variant="ghost" className="bg-card/80 hover:bg-card">
                <Share2 className="h-5 w-5" />
              </Button>
            </div>
          </div>
          {/* Image dots */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
            {dest.images.map((_, i) => (
              <button key={i} onClick={() => setCurrentImage(i)} className={`h-2 rounded-full transition-all ${i === currentImage ? "w-6 bg-white" : "w-2 bg-white/50"}`} />
            ))}
          </div>
        </div>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main */}
          <div className="lg:col-span-2 space-y-6">
            {/* Description */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <p className="text-muted-foreground leading-relaxed">{dest.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {dest.highlights.map((h) => (
                    <Badge key={h} variant="secondary" className="rounded-full">{h}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Tabs */}
            <Tabs defaultValue="activities">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="activities">Activities</TabsTrigger>
                <TabsTrigger value="hotels">Hotels</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              </TabsList>
              <TabsContent value="activities" className="mt-4 space-y-3">
                {dest.activities.map((a) => (
                  <Card key={a.name} className="border-0 shadow-sm">
                    <CardContent className="flex items-center justify-between p-4">
                      <div>
                        <h4 className="font-heading font-semibold">{a.name}</h4>
                        <div className="flex gap-3 text-xs text-muted-foreground mt-1">
                          <span className="flex items-center gap-1"><Clock className="h-3 w-3" /> {a.duration}</span>
                          <span className="flex items-center gap-1"><Star className="h-3 w-3 fill-secondary text-secondary" /> {a.rating}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-heading font-bold text-primary">${a.price}</p>
                        <Button size="sm" variant="outline" className="mt-1 text-xs">Book</Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              <TabsContent value="hotels" className="mt-4 space-y-3">
                {dest.hotels.map((h) => (
                  <Card key={h.name} className="border-0 shadow-sm">
                    <CardContent className="flex items-center justify-between p-4">
                      <div>
                        <h4 className="font-heading font-semibold">{h.name}</h4>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground"><Star className="h-3 w-3 fill-secondary text-secondary" /> {h.rating}</span>
                      </div>
                      <div className="text-right">
                        <p className="font-heading font-bold text-primary">${h.price}<span className="text-xs font-normal text-muted-foreground">/night</span></p>
                        <Button size="sm" variant="outline" className="mt-1 text-xs" asChild>
                          <Link to="/booking/hotels">Book</Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              <TabsContent value="reviews" className="mt-4 space-y-3">
                {dest.reviews_list.map((r) => (
                  <Card key={r.user} className="border-0 shadow-sm">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 font-heading font-semibold text-primary text-sm">{r.user[0]}</div>
                          <div>
                            <p className="font-semibold text-sm">{r.user}</p>
                            <p className="text-xs text-muted-foreground">{r.date}</p>
                          </div>
                        </div>
                        <div className="flex gap-0.5">{Array.from({ length: r.rating }).map((_, j) => <Star key={j} className="h-3 w-3 fill-secondary text-secondary" />)}</div>
                      </div>
                      <p className="text-sm text-muted-foreground">{r.text}</p>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Weather */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="font-heading text-base flex items-center gap-2"><CloudSun className="h-4 w-4 text-secondary" /> Weather</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Temperature</span><span className="font-semibold">{dest.weather.temp}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Condition</span><span className="font-semibold">{dest.weather.condition}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Humidity</span><span className="font-semibold">{dest.weather.humidity}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Best Months</span><span className="font-semibold">{dest.weather.bestMonths}</span></div>
              </CardContent>
            </Card>

            {/* Alerts */}
            {dest.alerts.length > 0 && (
              <Card className="border-0 shadow-sm border-l-4 border-l-secondary">
                <CardContent className="flex items-start gap-3 p-4">
                  <AlertTriangle className="h-5 w-5 text-secondary mt-0.5 shrink-0" />
                  <div>
                    <p className="font-heading font-semibold text-sm">Travel Advisory</p>
                    <p className="text-xs text-muted-foreground mt-1">{dest.alerts[0].message}</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* AI Itinerary */}
            <Card className="border-0 shadow-sm bg-gradient-to-br from-primary/5 to-accent/5">
              <CardContent className="p-4 text-center">
                <Sparkles className="mx-auto h-8 w-8 text-primary mb-2" />
                <h3 className="font-heading font-semibold text-sm mb-1">AI Itinerary</h3>
                <p className="text-xs text-muted-foreground mb-3">Let our AI plan your perfect trip to {dest.name}.</p>
                <Button size="sm" className="w-full gap-2" asChild>
                  <Link to="/itinerary/create"><Sparkles className="h-3 w-3" /> Generate Itinerary</Link>
                </Button>
              </CardContent>
            </Card>

            {/* Booking CTA */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4 space-y-3">
                <Button className="w-full gap-2" asChild>
                  <Link to="/booking/flights"><Plane className="h-4 w-4" /> Search Flights</Link>
                </Button>
                <Button variant="outline" className="w-full gap-2" asChild>
                  <Link to="/booking/hotels"><Hotel className="h-4 w-4" /> Find Hotels</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default DestinationDetails;

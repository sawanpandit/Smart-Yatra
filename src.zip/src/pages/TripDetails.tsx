import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  MapPin, Calendar, Users, DollarSign, Plane, Hotel, Clock,
  Plus, Share2, Edit, Sparkles, MessageSquare, FileText, ArrowRight,
  CheckCircle2, Circle,
} from "lucide-react";

const trip = {
  id: "1",
  destination: "Bali, Indonesia",
  image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800&h=300&fit=crop",
  startDate: "Mar 15, 2026",
  endDate: "Mar 22, 2026",
  status: "planned",
  budget: 2700,
  spent: 1250,
  participants: [
    { name: "You", role: "Organizer", avatar: "Y" },
    { name: "Sarah C.", role: "Member", avatar: "S" },
    { name: "James K.", role: "Member", avatar: "J" },
  ],
  itinerary: [
    {
      day: 1, date: "Mar 15", title: "Arrival & Seminyak",
      activities: [
        { time: "14:00", name: "Arrive at Ngurah Rai Airport", done: true },
        { time: "16:00", name: "Check in at hotel", done: true },
        { time: "19:00", name: "Sunset dinner at Ku De Ta", done: false },
      ],
    },
    {
      day: 2, date: "Mar 16", title: "Ubud Exploration",
      activities: [
        { time: "08:00", name: "Tegallalang Rice Terraces", done: false },
        { time: "12:00", name: "Lunch at Locavore", done: false },
        { time: "14:00", name: "Sacred Monkey Forest", done: false },
        { time: "18:00", name: "Traditional dance show", done: false },
      ],
    },
    {
      day: 3, date: "Mar 17", title: "Temple Day",
      activities: [
        { time: "06:00", name: "Sunrise at Lempuyang Temple", done: false },
        { time: "11:00", name: "Tirta Empul Holy Water Temple", done: false },
        { time: "16:00", name: "Uluwatu Temple sunset", done: false },
      ],
    },
  ],
  bookings: [
    { type: "Flight", name: "SQ Flight SIN→DPS", status: "confirmed", ref: "SQ-482934" },
    { type: "Hotel", name: "The Mulia Resort (7 nights)", status: "confirmed", ref: "ML-129384" },
  ],
};

const TripDetails = () => {
  const { id } = useParams();

  return (
    <Layout>
      {/* Hero */}
      <div className="relative h-48 sm:h-60 overflow-hidden">
        <img src={trip.image} alt={trip.destination} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="absolute bottom-4 left-0 right-0 container flex items-end justify-between">
          <div>
            <Badge className="mb-2 bg-primary/90 text-primary-foreground capitalize">{trip.status}</Badge>
            <h1 className="font-heading text-2xl font-bold text-white sm:text-3xl">{trip.destination}</h1>
            <div className="mt-1 flex items-center gap-4 text-white/80 text-sm">
              <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {trip.startDate} – {trip.endDate}</span>
              <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {trip.participants.length} travelers</span>
            </div>
          </div>
          <div className="hidden sm:flex gap-2">
            <Button size="sm" variant="outline" className="bg-card/80 border-0 gap-1"><Edit className="h-3 w-3" /> Edit</Button>
            <Button size="sm" variant="outline" className="bg-card/80 border-0 gap-1"><Share2 className="h-3 w-3" /> Share</Button>
          </div>
        </div>
      </div>

      <div className="container py-6">
        {/* Budget strip */}
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            { label: "Budget", value: `$${trip.budget.toLocaleString()}`, icon: DollarSign, color: "text-primary" },
            { label: "Spent", value: `$${trip.spent.toLocaleString()}`, icon: DollarSign, color: "text-accent" },
            { label: "Remaining", value: `$${(trip.budget - trip.spent).toLocaleString()}`, icon: DollarSign, color: "text-secondary-foreground" },
            { label: "Days", value: "7", icon: Calendar, color: "text-primary" },
          ].map((stat) => (
            <Card key={stat.label} className="border-0 shadow-sm">
              <CardContent className="flex items-center gap-3 p-4">
                <stat.icon className={`h-5 w-5 ${stat.color}`} />
                <div>
                  <p className="text-xs text-muted-foreground">{stat.label}</p>
                  <p className="font-heading font-bold">{stat.value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="itinerary">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="itinerary">Itinerary</TabsTrigger>
                <TabsTrigger value="bookings">Bookings</TabsTrigger>
                <TabsTrigger value="documents">Documents</TabsTrigger>
              </TabsList>

              <TabsContent value="itinerary" className="mt-4 space-y-4">
                {trip.itinerary.map((day) => (
                  <Card key={day.day} className="border-0 shadow-sm">
                    <CardHeader className="pb-2">
                      <CardTitle className="font-heading text-base flex items-center gap-2">
                        <Badge variant="secondary" className="text-xs">Day {day.day}</Badge>
                        {day.title}
                        <span className="ml-auto text-xs text-muted-foreground font-normal">{day.date}</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      {day.activities.map((a) => (
                        <div key={a.name} className="flex items-center gap-3 text-sm">
                          {a.done ? (
                            <CheckCircle2 className="h-4 w-4 text-accent shrink-0" />
                          ) : (
                            <Circle className="h-4 w-4 text-muted-foreground shrink-0" />
                          )}
                          <span className="text-xs text-muted-foreground w-12 shrink-0">{a.time}</span>
                          <span className={a.done ? "line-through text-muted-foreground" : ""}>{a.name}</span>
                        </div>
                      ))}
                    </CardContent>
                  </Card>
                ))}
                <Button variant="outline" className="w-full gap-2"><Plus className="h-4 w-4" /> Add Day</Button>
              </TabsContent>

              <TabsContent value="bookings" className="mt-4 space-y-3">
                {trip.bookings.map((b) => (
                  <Card key={b.ref} className="border-0 shadow-sm">
                    <CardContent className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        {b.type === "Flight" ? <Plane className="h-5 w-5 text-primary" /> : <Hotel className="h-5 w-5 text-primary" />}
                        <div>
                          <p className="font-semibold text-sm">{b.name}</p>
                          <p className="text-xs text-muted-foreground">Ref: {b.ref}</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-accent/10 text-accent capitalize">{b.status}</Badge>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>

              <TabsContent value="documents" className="mt-4">
                <Card className="border-0 shadow-sm">
                  <CardContent className="py-12 text-center">
                    <FileText className="mx-auto h-10 w-10 text-muted-foreground/50 mb-3" />
                    <p className="text-sm text-muted-foreground mb-3">No documents uploaded yet.</p>
                    <Button variant="outline" size="sm" className="gap-2"><Plus className="h-3 w-3" /> Upload Document</Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Participants */}
            <Card className="border-0 shadow-sm">
              <CardHeader className="pb-2">
                <CardTitle className="font-heading text-base flex items-center justify-between">
                  <span className="flex items-center gap-2"><Users className="h-4 w-4" /> Participants</span>
                  <Button variant="ghost" size="sm" className="text-primary text-xs"><Plus className="h-3 w-3 mr-1" /> Invite</Button>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {trip.participants.map((p) => (
                  <div key={p.name} className="flex items-center gap-3 text-sm">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 font-heading font-semibold text-primary text-xs">{p.avatar}</div>
                    <div>
                      <p className="font-medium">{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.role}</p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Expense tracker link */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-4">
                <Button className="w-full gap-2" variant="outline" asChild>
                  <Link to={`/trips/${id}/expenses`}>
                    <DollarSign className="h-4 w-4" /> View Expenses <ArrowRight className="h-3 w-3 ml-auto" />
                  </Link>
                </Button>
              </CardContent>
            </Card>

            {/* AI assistant */}
            <Card className="border-0 shadow-sm bg-gradient-to-br from-primary/5 to-accent/5">
              <CardContent className="p-4 text-center">
                <Sparkles className="mx-auto h-6 w-6 text-primary mb-2" />
                <p className="text-sm font-semibold mb-1">AI Trip Assistant</p>
                <p className="text-xs text-muted-foreground mb-3">Get suggestions to optimize your trip.</p>
                <Button size="sm" className="w-full gap-2" asChild>
                  <Link to="/ai-chat"><MessageSquare className="h-3 w-3" /> Chat with AI</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default TripDetails;
